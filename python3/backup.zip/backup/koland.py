#!/usr/bin/env python3
import os

scripts = [
    # SH
    "bash.sh",
    "bash2.sh",
    "backup.sh",

    "cust.sh",
    "cust1.sh",
    "cust2.sh",
    "cust3.sh",
    "cust5.sh",
    "cust6.sh",
    "cust7.sh",
    "cust8.sh",
    "cust9.sh",

    "custom.sh",
    "custom1.sh",
    "custom2.sh",
    "custom3.sh",
    "custom5.sh",
    "custom10.sh",

    "scaner206.sh",
    "scanner.sh",
    "scanner20.sh",
    "tarkib.sh",

    # BIN
    "senpaiscanner",

    # PY
    "custom.py",
    "custom1.py",
    "custom2.py",
    "custom5.py",
    "custom10.py",
    "custom11.py",

    "scan20.py",
    "scan80.py",
    "scan90.py",
    "scan100.py",
    "scan110.py",
    "scan120.py",
    "scan130.py",
    "scan200.py",
    "scan500.py",
    "scan700.py",

    # ONLINE
    "Kolande",
]


def show_menu():
    os.system("clear")

    print("\033[96m")
    print("╔══════════════════════════════╗")
    print("║       SCANNER LAUNCHER       ║")
    print("╚══════════════════════════════╝")
    print("\033[0m")

    for i, s in enumerate(scripts, 1):
        print(f"\033[92m[{i}]\033[0m {s}")

    print("\n\033[91m[0]\033[0m Exit")


while True:
    show_menu()
    choice = input("Select: ").strip()

    if choice == "0":
        break

    if choice.isdigit():
        idx = int(choice) - 1

        if 0 <= idx < len(scripts):
            file = scripts[idx]

            os.system("clear")
            print(f"Running: {file}\n")

            if file == "Kolande":
                os.system("bash <(curl -fsSL https://raw.githubusercontent.com/Kolandone/Selector/main/Sel.sh)")

            elif file.endswith(".py"):
                os.system(f"python3 '{file}'")

            elif file.endswith(".sh"):
                os.system(f"bash '{file}'")

            else:
                os.system(file)

            input("\nFinished. Press Enter...")
        else:
            input("Invalid!")

        continue

    input("Invalid! Press Enter...")
