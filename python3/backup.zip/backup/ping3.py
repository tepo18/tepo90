#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
from pathlib import Path
from rich import print
from rich.table import Table
from rich.panel import Panel
from rich.console import Console

# try import ping from ping3; ensure you don't have local ping3.py
try:
    from ping3 import ping
except Exception as e:
    # If ping import fails, define a dummy ping that returns None (so script still runs)
    def ping(host, timeout=1, unit="ms"):
        return None

console = Console()

# ==================== Fixed Personal Preset ====================
OUTPUT_FOLDER = "/storage/emulated/0/Download/almasi98"
Path(OUTPUT_FOLDER).mkdir(parents=True, exist_ok=True)

VALID_PING_MIN = 1
VALID_PING_MAX = 800
GOOD_THRESHOLD = 50
WARN_THRESHOLD = 200
TIMEOUT = 20.0
PING_COUNT = 10

# ==================== Banner ====================
console.print(Panel.fit(
    "[bold magenta]Almasi98 - Personal Ping Analyzer[/bold magenta]\n"
    "[cyan]Optimized for best accuracy with fixed custom settings[/cyan]",
    border_style="bright_magenta",
    title="[green]★ Ideal Personal Mode ★[/green]",
))

# ==================== Helpers ====================
def extract_host(config: str):
    m = re.search(r"@([^:/?#\s]+)", config)
    if m:
        return m.group(1)
    m = re.search(r"://([^:/?#\s]+)", config)
    return m.group(1) if m else None

def ping_host_nonhost(host: str, count: int = PING_COUNT, timeout: float = TIMEOUT):
    results = []
    for _ in range(count):
        try:
            r = ping(host, timeout=timeout, unit="ms")
            if r is not None:
                results.append(r)
        except Exception:
            continue
    if results:
        return sum(results) / len(results)
    return None

def classify_ping(avg_ms):
    if avg_ms is None:
        return "bad", "[bold red][BAD][/bold red]"
    try:
        if avg_ms < GOOD_THRESHOLD and VALID_PING_MIN <= avg_ms <= VALID_PING_MAX:
            return "good", "[bold green][GOOD][/bold green]"
        if avg_ms < WARN_THRESHOLD:
            return "warn", "[bold yellow][WARN][/bold yellow]"
    except Exception:
        pass
    return "bad", "[bold red][BAD][/bold red]"

# ==================== Input ====================
console.print(Panel.fit(
    "[cyan]Enter your configs line by line (VLESS/Trojan/SS)\n"
    "[white]Press [bold green]Ctrl+D[/bold green] (or Ctrl+Z + Enter on Windows) when done.[/white]",
    border_style="cyan", title="Input Configs"
))
configs = []
while True:
    try:
        line = input()
        if line.strip():
            configs.append(line.strip())
    except EOFError:
        break

if not configs:
    console.print("[bold red]No configs entered! Exiting.[/bold red]")
    exit()

console.print(Panel.fit(
    f"[green]Using Personal Preset:[/green]\n"
    f"[cyan]VALID_PING_MIN=[white]{VALID_PING_MIN}[/white], "
    f"VALID_PING_MAX=[white]{VALID_PING_MAX}[/white], "
    f"GOOD_THRESHOLD=[white]{GOOD_THRESHOLD}[/white], "
    f"WARN_THRESHOLD=[white]{WARN_THRESHOLD}[/white], "
    f"TIMEOUT=[white]{TIMEOUT}[/white], "
    f"PING_COUNT=[white]{PING_COUNT}[/white]",
    border_style="green", title="Active Configuration"
))

# ==================== Ping Process ====================
good, warn, bad = [], [], []
ping_results = {}
protocol_count = {"vless": 0, "trojan": 0, "ss": 0, "ignored": 0}

console.print("\n[bold magenta]Starting ping tests...[/bold magenta]\n")

for cfg in configs:
    host = extract_host(cfg)
    if not host:
        protocol_count["ignored"] += 1
        console.print(f"[yellow]Ignored (invalid):[/yellow] {cfg}")
        continue

    avg_ping = ping_host_nonhost(host)
    status, label = classify_ping(avg_ping)
    ping_results[cfg] = (status, avg_ping)

    color = "green" if status == "good" else "yellow" if status == "warn" else "red"
    if avg_ping is not None:
        try:
            console.print(f"[{color}]• {host:<40} -> {label} {avg_ping:.1f} ms[/]")
        except Exception:
            console.print(f"[{color}]• {host:<40} -> {label} {avg_ping}[/]")
    else:
        console.print(f"[red]• {host:<40} -> [BAD][/red]")

    if status == "good":
        good.append(cfg)
    elif status == "warn":
        warn.append(cfg)
    else:
        bad.append(cfg)

    if cfg.startswith("vless://"):
        protocol_count["vless"] += 1
    elif cfg.startswith("trojan://"):
        protocol_count["trojan"] += 1
    elif cfg.startswith("ss://") or cfg.startswith("ssss://"):
        protocol_count["ss"] += 1

# ==================== Summary ====================
summary = Table(title="Summary", style="cyan", header_style="bold magenta")
summary.add_column("Category", justify="left", style="white")
summary.add_column("Count", justify="center", style="bright_white")

summary.add_row("Total Configs", str(len(configs)))
summary.add_row("Green (GOOD)", f"[green]{len(good)}[/green]")
summary.add_row("Yellow (WARN)", f"[yellow]{len(warn)}[/yellow]")
summary.add_row("Red (BAD)", f"[red]{len(bad)}[/red]")
summary.add_row("VLESS", str(protocol_count["vless"]))
summary.add_row("TROJAN", str(protocol_count["trojan"]))
summary.add_row("SS/SSSS", str(protocol_count["ss"]))
summary.add_row("Ignored/Invalid", f"[dim]{protocol_count['ignored']}[/dim]")

console.print()
console.print(summary)
console.print(Panel.fit("[bold cyan]Ping process completed successfully.[/bold cyan]", border_style="green"))

# ==================== Output (automatic folder + files) ====================
def unique_dir(base: str):
    i = 0
    while True:
        name = base if i == 0 else f"{base}{i}"
        path = os.path.join(OUTPUT_FOLDER, name)
        if not os.path.exists(path):
            os.makedirs(path, exist_ok=True)
            return path
        i += 1

def unique_file_path(dirpath: str, base_name: str):
    base, ext = os.path.splitext(base_name)
    i = 0
    while True:
        fname = f"{base}{i if i > 0 else ''}{ext}"
        path = os.path.join(dirpath, fname)
        if not os.path.exists(path):
            return path
        i += 1

base_input = input("\n[bold cyan]Enter base folder name for outputs (e.g. ali):[/bold cyan] ").strip()
if not base_input:
    base_input = "output"

output_dir = unique_dir(base_input)
console.print(f"[green]Created/using output folder: {output_dir}[/green]\n")

lists_to_save = {
    "vless": [c for c in configs if c.startswith("vless://")],
    "trojan": [c for c in configs if c.startswith("trojan://")],
    "ss": [c for c in configs if c.startswith("ss://") or c.startswith("ssss://")],
    "green": [c for c in good if VALID_PING_MIN <= ((ping_results.get(c) or (None,0))[1] or 0) <= VALID_PING_MAX],
    "green_yellow": good + warn,
    "all": configs[:],
}

file_names = {
    "vless": "vless.txt",
    "trojan": "trojan.txt",
    "ss": "ss.txt",
    "green": "green.txt",
    "green_yellow": "green_yellow.txt",
    "all": "all.txt"
}

created_any = False
for key, fname in file_names.items():
    items = lists_to_save.get(key, [])
    outpath = unique_file_path(output_dir, fname)
    try:
        with open(outpath, "w", encoding="utf-8") as f:
            for ln in items:
                f.write(ln.rstrip() + "\n")
        console.print(f"[green]Wrote {len(items)} lines -> {outpath}[/green]")
        created_any = True
    except Exception as e:
        console.print(f"[red]Error writing {outpath}: {e}[/red]")

if not created_any:
    console.print("[yellow]هیچ فایلی ساخته نشد (خطا یا محدودیت دسترسی).[/yellow]")
else:
    console.print(f"\n[bold cyan]تمام فایل‌ها ساخته شدند در پوشه:[/bold cyan] {output_dir}")

# ==================== Port classification with 5+ digit handling ====================
console.print("\n[bold cyan]➕ Starting port classification & saving (add-on)...[/bold cyan]")

PORT_SAVE_DIR = "/storage/emulated/0/Download/port98"
os.makedirs(PORT_SAVE_DIR, exist_ok=True)

def extract_port(cfg: str):
    # Try common patterns (safe)
    m = re.search(r"port\s*=\s*(\d{1,6})", cfg, re.IGNORECASE)
    if m: return int(m.group(1))
    m = re.search(r"port\s*:\s*(\d{1,6})", cfg, re.IGNORECASE)
    if m: return int(m.group(1))
    m = re.search(r"://[^/]+:(\d{2,6})(?!\d)", cfg)
    if m: return int(m.group(1))
    m = re.search(r":(\d{2,6})(?!\d)", cfg)
    if m: return int(m.group(1))
    all_nums = re.findall(r"\b(\d{2,6})\b", cfg)
    if all_nums: return int(all_nums[-1])
    return None

port_map = {}
unknown_cfgs = []
all_port_cfgs = []

for cfg in configs:
    p = None
    try:
        p = extract_port(cfg)
    except Exception:
        p = None
    if p is None:
        unknown_cfgs.append(cfg)
    elif p >= 10000:
        all_port_cfgs.append(cfg)
    else:
        port_map.setdefault(p, []).append(cfg)

# Write files for ports < 10000
created_files = {}
for port in sorted(port_map.keys()):
    fname = os.path.join(PORT_SAVE_DIR, f"{port}.txt")
    try:
        with open(fname, "w", encoding="utf-8") as f:
            for ln in port_map[port]:
                f.write(ln + "\n")
        console.print(f"[green]✔ Saved {len(port_map[port])} configs -> {fname}[/green]")
        created_files[str(port)] = fname
    except Exception as e:
        console.print(f"[red]Error writing {fname}: {e}[/red]")

# Write all_port.txt for p >= 10000 (may be empty)
all_port_file = os.path.join(PORT_SAVE_DIR, "all_port.txt")
try:
    with open(all_port_file, "w", encoding="utf-8") as f:
        for ln in all_port_cfgs:
            f.write(ln + "\n")
    console.print(f"[green]✔ Saved {len(all_port_cfgs)} configs with 5+ digit ports -> {all_port_file}[/green]")
    created_files["all_port"] = all_port_file
except Exception as e:
    console.print(f"[red]Error writing all_port.txt: {e}[/red]")

# unknown_port.txt
unknown_path = os.path.join(PORT_SAVE_DIR, "unknown_port.txt")
try:
    with open(unknown_path, "w", encoding="utf-8") as f:
        for ln in unknown_cfgs:
            f.write(ln + "\n")
    console.print(f"[yellow]⚠ Saved {len(unknown_cfgs)} unknown-port configs -> {unknown_path}[/yellow]")
    if unknown_cfgs:
        created_files["unknown"] = unknown_path
except Exception as e:
    console.print(f"[red]Error writing unknown_port.txt: {e}[/red]")

# port.txt index (listing created files with counts)
port_index = os.path.join(PORT_SAVE_DIR, "port.txt")
try:
    with open(port_index, "w", encoding="utf-8") as idxf:
        # numeric keys (actual port files)
        numeric_keys = [k for k in created_files.keys() if k.isdigit()]
        numeric_keys_sorted = sorted(numeric_keys, key=lambda x: int(x))
        for k in numeric_keys_sorted:
            path = created_files.get(k)
            if path and os.path.exists(path):
                cnt = sum(1 for _ in open(path, "r", encoding="utf-8"))
            else:
                cnt = 0
            idxf.write(f"{os.path.basename(path)} ({cnt})\n")
        # include all_port if exists
        if "all_port" in created_files and os.path.exists(created_files["all_port"]):
            cnt = sum(1 for _ in open(created_files["all_port"], "r", encoding="utf-8"))
            idxf.write(f"{os.path.basename(created_files['all_port'])} ({cnt})\n")
        # include unknown if exists
        if "unknown" in created_files and os.path.exists(created_files["unknown"]):
            cnt = sum(1 for _ in open(created_files["unknown"], "r", encoding="utf-8"))
            idxf.write(f"{os.path.basename(created_files['unknown'])} ({cnt})\n")
    console.print(f"[green]✔ Wrote port index -> {port_index}[/green]")
except Exception as e:
    console.print(f"[red]Error writing port.txt index: {e}[/red]")

# Manifest file
manifest_path = os.path.join(PORT_SAVE_DIR, "manifest.txt")
try:
    with open(manifest_path, "w", encoding="utf-8") as mf:
        mf.write("Generated by Almasi98 integrated script\n")
        mf.write("Output directory: " + PORT_SAVE_DIR + "\n\n")
        mf.write("Files created:\n")
        for fn in sorted(os.listdir(PORT_SAVE_DIR)):
            mf.write("  " + fn + "\n")
    console.print(f"[green]✔ Manifest written -> {manifest_path}[/green]")
except Exception as e:
    console.print(f"[red]Error writing manifest: {e}[/red]")

# Print colored port usage table
try:
    port_table = Table(title="Port Usage Stats", header_style="bold magenta")
    port_table.add_column("Port", justify="center", style="cyan")
    port_table.add_column("Count", justify="center", style="white")

    # show <10000 ports individually
    for port in sorted(port_map.keys()):
        cnt = len(port_map[port])
        color = "green" if cnt > 10 else "yellow" if cnt > 3 else "red"
        port_table.add_row(str(port), f"[{color}]{cnt}[/]")

    # show summary row for 5+ digit ports
    if all_port_cfgs:
        port_table.add_row("[magenta]≥10000[/magenta]", f"[magenta]{len(all_port_cfgs)}[/magenta]")

    # unknown row
    if unknown_cfgs:
        port_table.add_row("[yellow]Unknown[/]", f"[red]{len(unknown_cfgs)}[/]")

    console.print()
    console.print(port_table)
    console.print("[bold green]✅ Port classification & saving completed.[/bold green]\n")
except Exception as e:
    console.print(f"[red]Error printing port table: {e}[/red]")

# End of script
