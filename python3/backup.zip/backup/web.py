from flask import Flask, send_from_directory
import os
import threading
import webbrowser
import time

BASE = "/storage/emulated/0/Download/html"
app = Flask(__name__)

files = [f for f in os.listdir(BASE) if f.lower().endswith(".html")]

# ===== routes =====
for f in files:
    route = "/" + f.replace(".html", "")

    def make_handler(filename):
        def handler():
            return send_from_directory(BASE, filename)
        return handler

    app.add_url_rule(route, route, make_handler(f))

@app.route("/")
def home():
    html = "<h2>HTML LAUNCHER</h2><ul>"
    for f in files:
        name = f.replace(".html", "")
        html += f'<li><a href="/{name}">{f}</a></li>'
    html += "</ul>"
    return html

def run_server():
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)

# ===== start server in background =====
threading.Thread(target=run_server, daemon=True).start()

# ===== wait a bit then open browser =====
time.sleep(1)

webbrowser.open("http://127.0.0.1:5000")

# ===== keep alive (no freeze warning) =====
while True:
    time.sleep(10)
