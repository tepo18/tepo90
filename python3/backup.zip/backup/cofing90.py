#!/usr/bin/env python3

import os
import re
import subprocess
import ipaddress
from datetime import datetime
from pathlib import Path
from colorama import Fore, init

init(autoreset=True)

VERSION = "2.0 PRO"

OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

BANNER = f"""
{Fore.CYAN}╔════════════════════════════════════════════════════╗
{Fore.CYAN}║ {Fore.GREEN} EXACT CONFIG COPY & IP REPLACER PRO {Fore.CYAN}       ║
{Fore.CYAN}║ {Fore.YELLOW} Version {VERSION}                              {Fore.CYAN}║
{Fore.CYAN}╚════════════════════════════════════════════════════╝
"""


def clear_screen():
    os.system("clear")


def pause():
    input(f"\n{Fore.GREEN}Press Enter to continue...{Fore.RESET}")


def copy_to_clipboard(text):
    try:
        p = subprocess.Popen(
            ["termux-clipboard-set"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        p.communicate(text.encode("utf-8"))

        return p.returncode == 0

    except Exception:
        return False


def clean_text(text):
    return text.strip().replace("\r", "")


def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def extract_ips(text):
    """
    استخراج IP های سالم از متن
    حذف پورت و تکراری ها
    """

    result = []

    items = re.split(
        r"[\s,;\n\r\t]+",
        text
    )

    for item in items:

        item = item.strip()

        if not item:
            continue

        # حذف پورت IPv4
        item = re.sub(
            r":\d+$",
            "",
            item
        )

        if is_valid_ip(item):

            if item not in result:
                result.append(item)

    return result


def detect_protocol(config):

    config_lower = config.lower()

    if config_lower.startswith("vless://"):
        return "VLESS"

    if config_lower.startswith("vmess://"):
        return "VMESS"

    if config_lower.startswith("trojan://"):
        return "TROJAN"

    if config_lower.startswith("ss://"):
        return "SHADOWSOCKS"

    if config_lower.startswith("hysteria"):
        return "HYSTERIA"

    return "UNKNOWN"


def extract_host(config):
    """
    پیدا کردن Host اصلی بدون تغییر بقیه کانفیگ
    """

    config = config.strip()

    if "@" in config:

        try:

            after_at = config.split(
                "@",
                1
            )[1]

            host = re.split(
                r"[:/?#]",
                after_at
            )[0]

            return host

        except:
            pass

    return None


def replace_host(config, old_host, new_ip):
    """
    فقط Host را عوض می‌کند
    بقیه لینک دست نخورده می‌ماند
    """

    if not old_host:
        return config

    new_config = config

    # حالت استاندارد @host:port
    new_config = new_config.replace(
        "@" + old_host + ":",
        "@" + new_ip + ":"
    )

    # حالت @host بدون پورت
    if new_config == config:

        new_config = new_config.replace(
            "@" + old_host,
            "@" + new_ip
        )

    return new_config


def remove_duplicates(items):
    """
    حذف کانفیگ‌های تکراری
    """

    seen = set()
    result = []

    for item in items:

        if item not in seen:

            seen.add(item)
            result.append(item)

    return result


def load_configs_from_text(text):

    configs = []

    for line in text.splitlines():

        line = line.strip()

        if "://" in line:

            configs.append(line)

    return configs


def load_file(path):

    try:

        with open(
            path,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:

            return f.read()

    except Exception:

        return ""


def save_output(filename, content):

    path = OUTPUT_DIR / filename

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(content)

    return path


def generate_configs(base_configs, ips):

    output = []

    stats = {}

    for config in base_configs:

        proto = detect_protocol(config)

        stats[proto] = (
            stats.get(proto, 0) + 1
        )

        old_host = extract_host(config)

        if not old_host:
            continue

        for ip in ips:

            new_conf = replace_host(
                config,
                old_host,
                ip
            )

            output.append(new_conf)

    output = remove_duplicates(output)

    return output, stats


def show_stats(base, ips, result):

    print("\n" + "=" * 45)

    print(
        f"{Fore.CYAN}Base Configs : "
        f"{Fore.GREEN}{len(base)}"
    )

    print(
        f"{Fore.CYAN}Clean IPs    : "
        f"{Fore.GREEN}{len(ips)}"
    )

    print(
        f"{Fore.CYAN}Generated    : "
        f"{Fore.GREEN}{len(result)}"
    )

    print("=" * 45)


def load_scanner_file():

    files = []

    for f in os.listdir("."):

        if (
            f.startswith("SenPaiScannerResult")
            or f.startswith("GOOD")
            or f.startswith("BAD")
        ):

            files.append(f)

    if not files:

        print(
            f"{Fore.RED}No scanner files found."
        )

        return ""

    print("\nAvailable Files:")

    for i, f in enumerate(files):

        print(
            f"[{i}] {f}"
        )

    try:

        choice = int(
            input(
                "\nSelect file: "
            )
        )

        return load_file(
            files[choice]
        )

    except:

        return ""


def main():

    base_configs = []

    # ==================================================
    # IP های انتخاب شده از SenPai
    # این متغیر بین گزینه های 2 و 3 حفظ می شود
    # ==================================================

    selected_ips = []

    while True:

        clear_screen()

        print(BANNER)

        if base_configs:

            print(
                f"{Fore.CYAN}Loaded Configs: "
                f"{Fore.GREEN}{len(base_configs)}"
            )

        else:

            print(
                f"{Fore.CYAN}Loaded Configs: "
                f"{Fore.RED}None"
            )

        # نمایش وضعیت IP های آماده
        if selected_ips:

            print(
                f"{Fore.CYAN}Loaded IPs   : "
                f"{Fore.GREEN}{len(selected_ips)}"
            )

        else:

            print(
                f"{Fore.CYAN}Loaded IPs   : "
                f"{Fore.RED}None"
            )

        print("\n" + "=" * 45)

        print(
            f"[{Fore.YELLOW}0{Fore.RESET}] Load Configs (Paste)"
        )

        print(
            f"[{Fore.BLUE}1{Fore.RESET}] Load Config File"
        )

        print(
            f"[{Fore.MAGENTA}2{Fore.RESET}] Load SenPai Result File"
        )

        print(
            f"[{Fore.GREEN}3{Fore.RESET}] Generate New Configs"
        )

        print(
            f"[{Fore.RED}9{Fore.RESET}] Exit"
        )

        print("=" * 45)

        choice = input(
            f"\n{Fore.GREEN}Select: {Fore.RESET}"
        ).strip()

        # ==================================================
        # EXIT
        # ==================================================

        if choice == "9":

            clear_screen()
            break

        # ==================================================
        # PASTE CONFIG
        # ==================================================

        elif choice == "0":

            clear_screen()

            print(
                f"{Fore.YELLOW}Paste configs"
            )

            print(
                f"{Fore.LIGHTBLACK_EX}"
                "(Finish with CTRL+D)"
                f"{Fore.RESET}\n"
            )

            data = []

            while True:

                try:

                    line = input()

                    if line.strip():

                        data.append(line)

                except EOFError:

                    break

            base_configs = load_configs_from_text(
                "\n".join(data)
            )

            print(
                f"\n{Fore.GREEN}Loaded:"
                f" {len(base_configs)}"
            )

            pause()

        # ==================================================
        # LOAD FILE
        # ==================================================

        elif choice == "1":

            filename = input(
                "\nConfig filename: "
            ).strip()

            text = load_file(filename)

            base_configs = load_configs_from_text(
                text
            )

            print(
                f"{Fore.GREEN}Loaded:"
                f" {len(base_configs)}"
            )

            pause()

        # ==================================================
        # SENPAI FILE
        # ==================================================

        elif choice == "2":

            clear_screen()

            print(BANNER)

            text = load_scanner_file()

            if not text:

                print(
                    f"\n{Fore.RED}"
                    "No data loaded from scanner file."
                )

                pause()
                continue

            # ------------------------------------------
            # استخراج IP ها
            # ------------------------------------------

            selected_ips = extract_ips(text)

            print(
                f"\n{Fore.GREEN}Found IPs:"
                f" {len(selected_ips)}"
            )

            # ------------------------------------------
            # اگر IP پیدا نشد
            # ------------------------------------------

            if not selected_ips:

                print(
                    f"\n{Fore.RED}"
                    "No valid IP found."
                )

                # پاک کردن لیست قبلی
                selected_ips = []

                pause()
                continue

            # ------------------------------------------
            # نمایش IP ها ستونی
            # ------------------------------------------

            print(
                f"\n{Fore.CYAN}"
                "Clean IPs:"
                f"{Fore.RESET}"
            )

            for i, ip in enumerate(
                selected_ips,
                start=1
            ):

                print(
                    f"{Fore.WHITE}"
                    f"{i:>4}. "
                    f"{Fore.GREEN}{ip}"
                )

            # ------------------------------------------
            # ذخیره فایل
            # ------------------------------------------

            save_output(
                "scanner_clean_ips.txt",
                "\n".join(selected_ips)
            )

            print(
                f"\n{Fore.CYAN}"
                "Saved scanner_clean_ips.txt"
            )

            # ------------------------------------------
            # کپی فوری IP ها به Clipboard
            # ------------------------------------------

            clipboard_text = (
                "\n".join(selected_ips)
                + "\n"
            )

            if copy_to_clipboard(
                clipboard_text
            ):

                print(
                    f"\n{Fore.GREEN}"
                    "✔ IPs copied to Termux clipboard"
                )

            else:

                print(
                    f"\n{Fore.YELLOW}"
                    "⚠ Clipboard unavailable"
                )

            # ------------------------------------------
            # پیام مهم برای گزینه 3
            # ------------------------------------------

            print(
                f"\n{Fore.CYAN}"
                "✔ IPs are ready for option [3]"
            )

            print(
                f"{Fore.LIGHTBLACK_EX}"
                "You can return to the main menu "
                "and select [3]."
                f"{Fore.RESET}"
            )

            pause()

        # ==================================================
        # GENERATE
        # ==================================================

        elif choice == "3":

            if not base_configs:

                print(
                    f"{Fore.RED}"
                    "Load configs first!"
                )

                pause()
                continue

            # ==================================================
            # اگر گزینه 2 قبلاً IPها را بارگذاری کرده باشد
            # مستقیماً همان IPها استفاده می شوند
            # ==================================================

            if selected_ips:

                ips = selected_ips.copy()

                print(
                    f"\n{Fore.GREEN}"
                    f"Using {len(ips)} IPs "
                    f"loaded from SenPai."
                )

                print(
                    f"{Fore.LIGHTBLACK_EX}"
                    "No need to paste them again."
                    f"{Fore.RESET}"
                )

            # ==================================================
            # اگر IP از گزینه 2 نداریم
            # رفتار قبلی حفظ می شود
            # ==================================================

            else:

                print(
                    f"\n{Fore.YELLOW}"
                    "Paste clean IPs"
                )

                print(
                    f"{Fore.LIGHTBLACK_EX}"
                    "(CTRL+D when finished)"
                    f"{Fore.RESET}\n"
                )

                lines = []

                while True:

                    try:

                        line = input()

                        if line.strip():

                            lines.append(line)

                    except EOFError:

                        break

                ips = extract_ips(
                    "\n".join(lines)
                )

            # ==================================================
            # بررسی IP
            # ==================================================

            if not ips:

                print(
                    f"{Fore.RED}"
                    "No valid IP found"
                )

                pause()

                continue

            # ==================================================
            # Generate
            # ==================================================

            results, stats = generate_configs(
                base_configs,
                ips
            )

            if not results:

                print(
                    f"{Fore.RED}"
                    "Nothing generated"
                )

                pause()

                continue

            show_stats(
                base_configs,
                ips,
                results
            )

            timestamp = datetime.now().strftime(
                "%Y%m%d_%H%M%S"
            )

            filename = (
                f"exact_configs_{timestamp}.txt"
            )

            output = "\n\n".join(results)

            path = save_output(
                filename,
                output
            )

            print(
                f"\n{Fore.GREEN}✔ Saved:"
                f" {path}"
            )

            # ==================================================
            # کپی کانفیگ های تولیدشده به Clipboard
            # ==================================================

            if copy_to_clipboard(output):

                print(
                    f"{Fore.GREEN}"
                    "✔ Copied to clipboard"
                )

            else:

                print(
                    f"{Fore.YELLOW}"
                    "Clipboard unavailable"
                )

            pause()


# ==============================================================
# EXTRA FEATURES PACK
# ==============================================================


def find_senpai_files():

    paths = [
        ".",
        "/data/data/com.termux/files/home",
        "/data/data/com.termux/files/home/storage/downloads",
        "/data/data/com.termux/files/home/storage/shared"
    ]

    found = []

    for base in paths:

        if not os.path.exists(base):
            continue

        try:

            for root, dirs, files in os.walk(base):

                for file in files:

                    if (
                        "SenPaiScannerResult" in file
                        or file.startswith("GOOD")
                        or file.startswith("BAD")
                    ):

                        found.append(
                            os.path.join(
                                root,
                                file
                            )
                        )

        except:

            pass

    return list(set(found))


def sort_ips(ip_list):

    try:

        return sorted(
            ip_list,
            key=lambda x: [
                int(i)
                for i in x.split(".")
            ]
        )

    except:

        return ip_list


def save_ip_list(ips):

    ips = sort_ips(ips)

    filename = (
        "clean_ips_"
        +
        datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )
        +
        ".txt"
    )

    path = OUTPUT_DIR / filename

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            "\n".join(ips)
        )

    return path


def advanced_scanner_menu():

    clear_screen()

    print(BANNER)

    files = find_senpai_files()

    if not files:

        print(
            f"{Fore.RED}"
            "No SenPai files found"
        )

        pause()

        return []

    print(
        f"{Fore.CYAN}"
        "Scanner files found:"
    )

    for i, f in enumerate(files):

        print(
            f"[{i}] {f}"
        )

    try:

        num = int(
            input(
                "\nSelect file: "
            )
        )

        data = load_file(
            files[num]
        )

        ips = extract_ips(
            data
        )

        ips = sort_ips(
            ips
        )

        saved = save_ip_list(
            ips
        )

        print(
            f"\n{Fore.GREEN}"
            f"Found IPs: {len(ips)}"
        )

        print(
            f"{Fore.CYAN}"
            f"Saved: {saved}"
        )

        pause()

        return ips

    except Exception:

        print(
            f"{Fore.RED}"
            "Invalid selection"
        )

        pause()

        return []


# ==============================================================
# START
# ==============================================================

if __name__ == "__main__":

    main()
