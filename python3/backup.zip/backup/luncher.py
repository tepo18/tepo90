#!/usr/bin/env python3
import os

scripts = {
    "1": "sanpi.sh",
    "2": "scan.sh",
    "3": "scan10.sh",
    "4": "scan100.py",
    "5": "scan110.py",
    "6": "scan120.py",
    "7": "scan130.py",
    "8": "scan20.py",
    "9": "scan200.py",
    "10": "scan30.sh",
    "11": "scan80.py",
    "12": "scan90.py",
    "13": "scaneer.sh",
    "14": "scanner.py",
    "15": "scanner.sh",
    "16": "scanner10.sh",
    "17": "scanner20.py",
    "18": "scanner20.sh"
}

while True:
    os.system("clear")

    print("\033[96m")
    print("╔══════════════════════════════╗")
    print("║       SCANNER LAUNCHER      ║")
    print("╚══════════════════════════════╝")
    print("\033[0m")

    for n, s in scripts.items():
        print(f"\033[92m[{n}]\033[0m {s}")

    print("\n\033[91m[0]\033[0m Exit\n")

    choice = input("Select: ").strip()

    if choice == "0":
        break

    if choice not in scripts:
        input("Invalid! Enter...")
        continue

    file = scripts[choice]

    os.system("clear")
    print(f"Running {file}\n")

    if file.endswith(".py"):
        os.system(f"python {file}")
    else:
        os.system(f"bash {file}")

    print("\n")
    input("Finished. Press Enter for Menu...")
