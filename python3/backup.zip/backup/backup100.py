#!/usr/bin/env python3

import os
import shutil
import sys

HOME = os.path.expanduser("~")
BACKUP_DIR = os.path.join(HOME, "storage", "downloads", "backup")


# =========================
# COLORS
# =========================
RESET = "\033[0m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BLUE = "\033[94m"
WHITE = "\033[97m"
BOLD = "\033[1m"


# =========================
# SCREEN
# =========================
def clear():
    os.system("clear")


def pause():
    input(f"\n{YELLOW}Press ENTER to continue...{RESET}")


# =========================
# HEADER
# =========================
def header():
    print(f"{CYAN}{BOLD}")
    print("======================================")
    print("        PYTHON / SHELL BACKUP")
    print("======================================")
    print(f"{RESET}")


# =========================
# GET SCRIPTS FROM HOME
# =========================
def get_home_scripts():
    files = []

    try:
        for name in os.listdir(HOME):
            path = os.path.join(HOME, name)

            if not os.path.isfile(path):
                continue

            if name.endswith(".py") or name.endswith(".sh"):
                files.append(path)

    except Exception as e:
        print(f"{RED}Error reading Home: {e}{RESET}")

    return files


# =========================
# BACKUP
# =========================
def backup():

    clear()
    header()

    print(f"{BLUE}Creating backup...{RESET}\n")

    try:
        # Remove old backup completely
        if os.path.exists(BACKUP_DIR):
            shutil.rmtree(BACKUP_DIR)

        os.makedirs(BACKUP_DIR, exist_ok=True)

        files = get_home_scripts()

        if not files:
            print(f"{YELLOW}No .py or .sh files found in Home.{RESET}")
            pause()
            return

        count = 0

        for src in files:
            filename = os.path.basename(src)
            dst = os.path.join(BACKUP_DIR, filename)

            shutil.copy2(src, dst)
            count += 1

        print(f"{GREEN}{BOLD}BACKUP COMPLETE{RESET}")
        print(f"{GREEN}Files copied: {count}{RESET}")
        print(f"{CYAN}Location:{RESET} {BACKUP_DIR}")

    except Exception as e:
        print(f"{RED}{BOLD}BACKUP ERROR:{RESET} {e}")

    pause()


# =========================
# RESTORE
# =========================
def restore():

    clear()
    header()

    print(f"{BLUE}Restoring from backup...{RESET}\n")

    if not os.path.isdir(BACKUP_DIR):
        print(f"{RED}Backup folder not found!{RESET}")
        print(f"{YELLOW}{BACKUP_DIR}{RESET}")
        pause()
        return

    try:
        count = 0

        for filename in os.listdir(BACKUP_DIR):

            src = os.path.join(BACKUP_DIR, filename)

            # Only files
            if not os.path.isfile(src):
                continue

            # Only Python and Shell scripts
            if not (filename.endswith(".py") or filename.endswith(".sh")):
                continue

            dst = os.path.join(HOME, filename)

            # If same file already exists in Home,
            # remove it before restoring backup copy.
            if os.path.exists(dst):
                os.remove(dst)

            shutil.copy2(src, dst)

            # Restore execute permission
            try:
                os.chmod(dst, os.stat(dst).st_mode | 0o111)
            except Exception:
                pass

            count += 1

        print(f"{GREEN}{BOLD}RESTORE COMPLETE{RESET}")
        print(f"{GREEN}Files restored: {count}{RESET}")
        print(f"{CYAN}Restored to:{RESET} {HOME}")

    except Exception as e:
        print(f"{RED}{BOLD}RESTORE ERROR:{RESET} {e}")

    pause()


# =========================
# MENU
# =========================
def menu():

    while True:

        clear()
        header()

        print(f"{GREEN}[1]{RESET} {WHITE}Backup scripts{RESET}")
        print(f"{YELLOW}[2]{RESET} {WHITE}Restore from backup{RESET}")
        print(f"{RED}[3]{RESET} {WHITE}Exit{RESET}")

        print()
        choice = input(f"{CYAN}Select: {RESET}").strip()

        if choice == "1":
            backup()

        elif choice == "2":
            restore()

        elif choice == "3":
            clear()
            print(f"{GREEN}Goodbye!{RESET}")
            sys.exit(0)

        else:
            print(f"{RED}Invalid option!{RESET}")
            pause()


# =========================
# START
# =========================
if __name__ == "__main__":
    menu()
