#!/usr/bin/env python3
import os

scripts = [
    # ===== SH =====
    "aether.sh",
    "asl.sh",
    "backup.sh",
    "chat.sh",
    "clean_ips.sh",
    "cust.sh",
    "cust1.sh",
    "cust2.sh",
    "cust3.sh",
    "cust5.sh",
    "cust6.sh",
    "cust7.sh",
    "cust8.sh",
    "cust9.sh",
    "custom.sh",
    "custom1.sh",
    "custom10.sh",
    "custom2.sh",
    "custom5.sh",
    "ether.sh",
    "html-launcher.sh",
    "html.sh",
    "ip_cleaner.sh",
    "ip_merge.sh",
    "nahan.sh",
    "start.sh",
    "sub10.sh",
    "tarkib.sh",
    "tarkib20.sh",
    "vip30.sh",

    # ===== PY =====
    "akbar.py",
    "bade14.py",
    "bakup.py",
    "bakup2.py",
    "cofing.py",
    "cofing10.py",
    "cofing20.py",
    "cofing30.py",
    "custom.py",
    "custom1.py",
    "custom10.py",
    "custom11.py",
    "custom2.py",
    "custom3.py",
    "custom5.py",
    "cut.py",
    "cut1.py",
    "cut2.py",
    "cut3.py",
    "cut10.py",
    "freg21.py",
    "freg23.py",
    "ip.py",
    "javed.py",
    "javed1.py",
    "javed2.py",
    "javed9.py",
    "javed10.py",
    "koland.py",
    "koland10.py",
    "link.py",
    "lunch.py",
    "lunch2.py",
    "lunch3.py",
    "lunch10.py",
    "lunch30.py",
    "lunch50.py",
    "lunch90.py",
    "lunch98.py",
    "luncher.py",
    "omid.py",
    "root.py",
    "senpi.py",
    "spot.py",
    "spot1.py",
    "spot2.py",
    "spot3.py",
    "spot4.py",
    "spot5.py",
    "spot10.py",
    "spot20.py",
    "spot90.py",
    "star.py",
    "star1.py",
    "star2.py",
    "start.py",
    "store.py",
    "sub.py",
    "sub1.py",
    "sub3.py",
    "sub4.py",
    "sub5.py",
    "sub8.py",
    "sub9.py",
    "sub10.py",
    "sub20.py",
    "sub30.py",
    "v2ray.py",
    "wegard.py",

    # ===== OTHER =====
    "clean.txt",
    "clean_ips.txt",
    "input.txt",
    "ips.txt",
    "output_ips.txt",
    "targets.txt",
    "eather",
    "senpi",
]


def show_menu():
    os.system("clear")

    print("\033[96m")
    print("╔══════════════════════════════╗")
    print("║       SCANNER LAUNCHER       ║")
    print("╚══════════════════════════════╝")
    print("\033[0m")

    for i, s in enumerate(scripts, 1):
        print(f"\033[92m[{i}]\033[0m {s}")

    print("\n\033[91m[0]\033[0m Exit")


while True:
    show_menu()
    choice = input("Select: ").strip()

    if choice == "0":
        break

    if choice.isdigit():
        idx = int(choice) - 1

        if 0 <= idx < len(scripts):
            file = scripts[idx]

            os.system("clear")
            print(f"Running: {file}\n")

            if file == "Kolande":
                os.system(
                    "bash <(curl -fsSL "
                    "https://raw.githubusercontent.com/Kolandone/Selector/main/Sel.sh)"
                )

            elif file.endswith(".py"):
                os.system(f"python3 '{file}'")

            elif file.endswith(".sh"):
                os.system(f"bash '{file}'")

            else:
                os.system(f"'{file}'")

            input("\nFinished. Press Enter...")

        else:
            input("Invalid!")

        continue

    input("Invalid! Press Enter...")
