import os
import re
import subprocess
from datetime import datetime
import ipaddress
from colorama import Fore, init

init(autoreset=True)

BANNER = f"""
{Fore.CYAN}╔════════════════════════════════════════════════════╗
{Fore.CYAN}║ {Fore.GREEN} 🚀     EXACT CONFIG COPY & IP REPLACER        {Fore.CYAN} ║
{Fore.CYAN}╚════════════════════════════════════════════════════╝
"""

def clear_screen():
    os.system('clear')

def copy_to_clipboard(text):
    try:
        process = subprocess.Popen(['termux-clipboard-set'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        process.communicate(input=text.encode('utf-8'))
        return True
    except:
        return False

def extract_current_ip_or_host(config):
    """استخراج دقیق بخش سرور (آی‌پی یا دامین) بدون دستکاری پورت یا بقیه متن"""
    config = config.strip()
    # برای کانفیگ‌های رایج vless, vmess, trojan, ss که فرمت @host:port دارند
    if "@" in config:
        main_part = config.split("@")[1]
        # جدا کردن بر اساس اولین دونقطه بعد از @ برای یافتن پورت یا شروع پارامترها
        host_part = re.split(r'[:/?#]', main_part)[0]
        return host_part
    return None

def extract_ips_from_text(raw_text):
    potential_ips = re.split(r'[\s,\n\r\t]+', raw_text)
    valid_ips = []
    for item in potential_ips:
        item = item.strip()
        if not item:
            continue
        ip_clean = re.sub(r':\d+$', '', item) # حذف پورت احتمالی چسبیده به آی‌پی
        try:
            ipaddress.ip_address(ip_clean)
            if ip_clean not in valid_ips:
                valid_ips.append(ip_clean)
        except ValueError:
            pass
    return valid_ips

def main():
    base_configs = []
    while True:
        clear_screen()
        print(BANNER)
        if base_configs:
            print(f"{Fore.CYAN}Loaded Base Configs: {Fore.GREEN}{len(base_configs)}")
        else:
            print(f"{Fore.CYAN}Loaded Base Configs: {Fore.RED}None")
            
        print("\n" + "="*30)
        print(f"[{Fore.YELLOW}0{Fore.RESET}] Load Base Configs (Any Link: Vless, Trojan, ShadowSocks, etc.)")
        print(f"[{Fore.CYAN}1{Fore.RESET}] Paste Clean IPs directly in Terminal & Generate")
        print(f"[{Fore.RED}9{Fore.RESET}] Exit")
        print("="*30)
        
        choice = input(f"\n{Fore.GREEN}Select an option:{Fore.RESET} ").strip()
        
        if choice == '9':
            clear_screen()
            break
            
        if choice == '0':
            clear_screen()
            print(BANNER)
            print(f"{Fore.YELLOW}>> Paste your original Config(s) below.")
            print(f"{Fore.LIGHTBLACK_EX}(Press ENTER, then CTRL+D when finished){Fore.RESET}\n")
            base_input = []
            while True:
                try:
                    line = input()
                    if line.strip():
                        base_input.append(line.strip())
                except EOFError:
                    break
            base_configs = [c for c in base_input if "://" in c]
            continue
            
        if not base_configs:
            print(f"\n{Fore.RED}Please Load Base Configs first (Option 0)!")
            input("\nPress Enter to continue...")
            continue
            
        if choice == '1':
            print(f"\n{Fore.YELLOW}>> Paste your Clean IP list here:")
            print(f"{Fore.LIGHTBLACK_EX}(When done, press ENTER then CTRL+D){Fore.RESET}\n")
            ip_lines = []
            while True:
                try:
                    line = input()
                    if line.strip():
                        ip_lines.append(line.strip())
                except EOFError:
                    break
            
            raw_text = " ".join(ip_lines)
            clean_ips = extract_ips_from_text(raw_text)
            
            if not clean_ips:
                print(f"\n{Fore.RED}No valid IPs found.")
                input("\nPress Enter...")
                continue
                
            generated_configs = []
            for original_config in base_configs:
                old_host = extract_current_ip_or_host(original_config)
                if not old_host:
                    continue
                
                for new_ip in clean_ips:
                    # کپی دقیق متن بدون تغییر ساختار و فقط جایگزینی بخش سرور
                    new_conf = original_config.replace(f"@{old_host}:", f"@{new_ip}:")
                    # برای حالت‌هایی که بعد از هاست پورت نیست و مستقیماً غیراستاندارد جدا شده
                    if new_conf == original_config:
                        new_conf = original_config.replace(old_host, new_ip, 1)
                        
                    generated_configs.append(new_conf)
            
            if generated_configs:
                final_output = "\n\n".join(generated_configs) + "\n"
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"exact_copied_configs_{timestamp}.txt"
                
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(final_output)
                
                print("-" * 40)
                print(f"[{Fore.GREEN}✔{Fore.RESET}] Done! Total Input Configs: {len(base_configs)} | Total Clean IPs: {len(clean_ips)}")
                print(f"[{Fore.GREEN}✔{Fore.RESET}] Successfully generated {Fore.GREEN}{len(generated_configs)}{Fore.RESET} exact copies!")
                print(f"[{Fore.BLUE}ℹ{Fore.RESET}] Saved to file: {Fore.CYAN}{filename}")
                
                if copy_to_clipboard(final_output.strip()):
                    print(f"[{Fore.GREEN}✔{Fore.RESET}] All configs copied to your clipboard!")
                else:
                    print(f"[{Fore.YELLOW}!{Fore.RESET}] Clipboard error, please use the saved file.")
            else:
                print(f"\n{Fore.RED}Failed to replace IPs. Check config format.")
                
            input(f"\n{Fore.GREEN}Press Enter to return to Main Menu...{Fore.RESET}")

if __name__ == "__main__":
    main()
