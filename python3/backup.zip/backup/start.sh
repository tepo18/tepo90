#!/data/data/com.termux/files/usr/bin/bash

cd /storage/emulated/0/Download/html || exit

echo -e "\e[32m[+] Starting Python HTTP Server...\e[0m"

python -m http.server 8000 &

sleep 2

echo -e "\e[34m[+] Opening browser...\e[0m"

termux-open-url http://127.0.0.1:8000
