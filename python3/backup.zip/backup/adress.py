https://detectportal.firefox.com

https://cp.cloudflare.com/

http://connectivitycheck.gstatic.com/generate_204

http://captive.apple.com/hotspot-detect.html

https://www.gstatic.com/generate_204

https://www.google.com/gen_204

https://www.gstatic.com/generate_204

https://cp.cloudflare.com/

https://connectivitycheck.gstatic.com/generate_204

https://www.google.com/generate_204



https://detectportal.firefox.com/success.txt

http://www.gstatic.com/ipranges/cloud.json


https://clients3.google.com/generate_204

https://www.google.com/favicon.ico

https://clients2.google.com/generate_204
https://clients4.google.com/generate_204
https://clients5.google.com/generate_204
https://clients6.google.com/generate_204


https://www.cloudflare.com/cdn-cgi/trace


https://api.ip.sb/geoip
