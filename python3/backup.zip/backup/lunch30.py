#!/usr/bin/env python3
import os

scripts = [
    "scan20.py",
    "scan80.py",
    "scan90.py",
    "scan100.py",
    "scan110.py",
    "scan120.py",
    "scan130.py",
    "scan200.py",
    "scan500.py",
    "bash.sh",
    "bash2.sh",
    "backup.sh",
    "custom10.sh",
    "scaner206.sh",
    "scanner.sh",
    "scanner20.sh",
    "tarkib.sh",
]

def show_menu():
    os.system("clear")

    print("\033[96m")
    print("╔══════════════════════════════╗")
    print("║       SCANNER LAUNCHER      ║")
    print("╚══════════════════════════════╝")
    print("\033[0m")

    for i, s in enumerate(scripts, 1):
        print(f"\033[92m[{i}]\033[0m {s}")

    print("\n\033[91m[0]\033[0m Exit")


while True:
    show_menu()
    choice = input("Select: ").strip()

    if choice == "0":
        break

    if choice.isdigit():
        idx = int(choice) - 1

        if 0 <= idx < len(scripts):
            file = scripts[idx]

            os.system("clear")
            print(f"Running: {file}\n")

            if file.endswith(".py"):
                os.system(f"python3 {file}")
            else:
                os.system(f"bash {file}")

            input("\nFinished. Press Enter...")
        else:
            input("Invalid!")
        continue

    input("Invalid! Enter...")

