#!/data/data/com.termux/files/usr/bin/bash

# Colors
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
NC='\033[0m'

clear
echo -e "${CYAN}=== CUSTOM CONFIG GENERATOR ===${NC}"
echo

# 1. NAME FIRST
read -p "NAME (remarks): " REMARKS

# 2. IP / ADDRESS
read -p "IP / ADDRESS: " IP

# 3. PORT (FIXED)
PORT=443

# 4. PASSWORD
read -p "PASSWORD: " PASSWORD

# 5. HOST
read -p "HOST: " HOST

# 6. SNI
read -p "SNI: " SNI

echo
echo -e "${GREEN}=== GENERATED CONFIG ===${NC}"
echo

cat <<EOF
{
"remarks": "$REMARKS",

"log": {
"access": "",
"error": "",
"loglevel": "info",
"dnsLog": false
},

"inbounds": [
{
"tag": "in_proxy",
"port": 1080,
"protocol": "socks",
"listen": "0.0.0.0",
"settings": {
"auth": "noauth",
"udp": true,
"userLevel": 8
},
"sniffing": {
"enabled": false
}
},
{
"tag": "http-in",
"port": 10808,
"listen": "::",
"protocol": "http"
}
],

"outbounds": [
{
"tag": "proxy",
"protocol": "trojan",
"settings": {
"servers": [
{
"address": "$IP",
"method": "chacha20-poly1305",
"ota": false,
"password": "$PASSWORD",
"port": $PORT,
"level": 8,
"flow": ""
}
]
},
"streamSettings": {
"network": "ws",
"security": "tls",
"wsSettings": {
"path": "",
"headers": {
"Host": "$HOST"
}
},
"tlsSettings": {
"allowInsecure": true,
"serverName": "$SNI",
"alpn": ["http/1.1"],
"fingerprint": "ios",
"show": false
},
"sockopt": {
"dialerProxy": "fragment",
"tcpKeepAliveIdle": 100,
"tcpNoDelay": true
}
},
"mux": {
"enabled": false,
"concurrency": 8
}
}
],

"dns": {
"servers": ["8.8.8.8"]
},

"routing": {
"domainStrategy": "UseIp",
"rules": [],
"balancers": []
}
}
EOF
