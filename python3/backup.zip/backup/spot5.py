#!/usr/bin/env python3
import os

scripts = [
    # ===== SH =====
    "asl.sh",
    "backup.sh",
    "tarkib.sh",
    "cust.sh",
    "cust1.sh",
    "cust2.sh",
    "cust3.sh",
    "cust5.sh",
    "cust6.sh",
    "cust7.sh",
    "cust8.sh",
    "cust9.sh",
    "clean_ips.sh",
    "aether.sh",
    "nahan.sh",
    "ip_merge.sh",
    "html.sh",
    "ip_cleaner.sh",
    "html-launcher.sh",
    "ether.sh",
    "custom.sh",
    "custom1.sh",
    "custom10.sh",
    "custom2.sh",
    "custom5.sh",
    "bas.sh",
    "bash.sh",
    "bash1.sh",
    "bash10.sh",
    "bash11.sh",
    "bash13.sh",
    "bash14.sh",
    "bash15.sh",
    "bash16.sh",
    "bash17.sh",
    "bash18.sh",
    "bash19.sh",
    "bash2.sh",
    "bash20.sh",
    "bash3.sh",
    "bash4.sh",
    "bash5.sh",
    "bash6.sh",
    "bash7.sh",
    "bash8.sh",
    "bash9.sh",
    "chat.sh",
    "sub10.sh",
    "vip.sh",
    "vip1.sh",
    "vip2.sh",
    "vip3.sh",
    "vip4.sh",
    "vip5.sh",
    "vip6.sh",
    "vip7.sh",
    "vip8.sh",
    "vip9.sh",
    "vip10.sh",
    "vip11.sh",
    "vip12.sh",
    "vip13.sh",
    "vip14.sh",
    "vip15.sh",
    "vip16.sh",
    "vip17.sh",
    "vip18.sh",
    "vip19.sh",
    "vip20.sh",
    "vip21.sh",
    "vip22.sh",
    "vip25.sh",
    "vip30.sh",

    # ===== PY =====
    "akbar.py",
    "wegard.py",
    "cofing.py",
    "omid.py",
    "lunch.py",
    "lunch2.py",
    "lunch3.py",
    "lunch10.py",
    "lunch30.py",
    "lunch50.py",
    "lunch90.py",
    "lunch98.py",
    "luncher.py",
    "link.py",
    "koland.py",
    "koland10.py",
    "cut.py",
    "cut1.py",
    "cut2.py",
    "cut3.py",
    "cut10.py",
    "freg21.py",
    "freg23.py",
    "custom.py",
    "custom1.py",
    "custom10.py",
    "custom11.py",
    "custom2.py",
    "custom5.py",
    "bakup.py",
    "bakup2.py",
    "senpi.py",
    "clash.py",
    "clash1.py",
    "clash2.py",
    "bade14.py",
    "g.py",
    "mago.py",
    "mago1.py",
    "mago3.py",
    "sub.py",
    "sub1.py",
    "sub10.py",
    "sub20.py",
    "sub3.py",
    "sub30.py",
    "sub4.py",
    "sub5.py",
    "sub8.py",
    "sub9.py",
    "v2ray.py",
    "web.py",
    "web1.py",
    "web2.py",

    # ===== OTHER =====
    "targets.txt",
    "clean.txt",
    "clean_ips.txt",
    "output_ips.txt",
    "input",
    "input.txt",
    "ips.txt",
    "go",
]
def show_menu():
    os.system("clear")

    print("\033[96m")
    print("╔══════════════════════════════╗")
    print("║       SCANNER LAUNCHER       ║")
    print("╚══════════════════════════════╝")
    print("\033[0m")

    for i, s in enumerate(scripts, 1):
        print(f"\033[92m[{i}]\033[0m {s}")

    print("\n\033[91m[0]\033[0m Exit")


while True:
    show_menu()
    choice = input("Select: ").strip()

    if choice == "0":
        break

    if choice.isdigit():
        idx = int(choice) - 1

        if 0 <= idx < len(scripts):
            file = scripts[idx]

            os.system("clear")
            print(f"Running: {file}\n")

            if file == "Kolande":
                os.system("bash <(curl -fsSL https://raw.githubusercontent.com/Kolandone/Selector/main/Sel.sh)")

            elif file.endswith(".py"):
                os.system(f"python3 '{file}'")

            elif file.endswith(".sh"):
                os.system(f"bash '{file}'")

            else:
                os.system(file)

            input("\nFinished. Press Enter...")
        else:
            input("Invalid!")

        continue

    input("Invalid! Press Enter...")


