#!/usr/bin/env python3
import os

scripts = [
    "asl.sh",
    "backup.sh",
    "targets.txt",
    "tarkib.sh",
    "akbar.py",
    "wegard.py",

    "cofing.py",

    "senpi",
    "Aether",
    "akbar10.py",
    "akbar.py",
    "bas.sh",
    "bakup.py",
    "bakup2.py",
    "backup.sh",
    "clean_ips.sh",

    "clean.txt",
    "clean_ips.sh",
    "clean_ips.txt",
    "ips.txt",
    "output_ips.txt",
    "ip_merge.sh",
    "root.py",

    "lunch.py",
    "lunch10.py",
    "lunch2.py",
    "lunch3.py",
    "lunch30.py",
    "lunch50.py",
    "lunch90.py",
    "lunch98.py",
    "luncher.py",

    "link.py",
    "koland.py",
    "koland10.py",
    "ip_merge.sh",
    "spot10.py",
    "ip_cleaner.sh",
    "spot20.py",
    "ether.sh",

    "cut.py",
    "cut1.py",
    "cut10.py",
    "cut2.py",
    "cut3.py",

    "freg21.py",
    "freg23.py",

    "custom.py",
    "custom.sh",
    "custom1.py",
    "custom1.sh",
    "custom10.py",
    "custom10.sh",
    "custom11.py",
    "custom2.py",
    "custom2.sh",
    "custom3.sh",
    "custom5.py",
    "custom5.sh",

    "bakup.py",
    "bakup2.py",
    "bas.sh",
    "senpi.py",

]

def show_menu():
    os.system("clear")

    print("\033[96m")
    print("╔══════════════════════════════╗")
    print("║       SCANNER LAUNCHER       ║")
    print("╚══════════════════════════════╝")
    print("\033[0m")

    for i, s in enumerate(scripts, 1):
        print(f"\033[92m[{i}]\033[0m {s}")

    print("\n\033[91m[0]\033[0m Exit")


while True:
    show_menu()
    choice = input("Select: ").strip()

    if choice == "0":
        break

    if choice.isdigit():
        idx = int(choice) - 1

        if 0 <= idx < len(scripts):
            file = scripts[idx]

            os.system("clear")
            print(f"Running: {file}\n")

            if file == "Kolande":
                os.system("bash <(curl -fsSL https://raw.githubusercontent.com/Kolandone/Selector/main/Sel.sh)")

            elif file.endswith(".py"):
                os.system(f"python3 '{file}'")

            elif file.endswith(".sh"):
                os.system(f"bash '{file}'")

            else:
                os.system(file)

            input("\nFinished. Press Enter...")
        else:
            input("Invalid!")

        continue

    input("Invalid! Press Enter...")



