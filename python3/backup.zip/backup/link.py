#!/usr/bin/env python3
import os

# رنگ‌ها
GREEN = "\033[1;32m"
CYAN = "\033[1;36m"
YELLOW = "\033[1;33m"
RED = "\033[1;31m"
RESET = "\033[0m"

# ==========================
# لینک‌ها و نام‌ها (قابل تغییر در آینده)
# ==========================
private_links = [
    ("arista", "https://tepo98.ahsan-tepo20.workers.dev/api/arista-panel-v2ray"),
    ("hestrya", "https://raw.githubusercontent.com/arshiacomplus/v2rayExtractor/main/hy2.html"),
    ("panel chini", "https://chine-panel.ahsan-tepo98.workers.dev/c808ce19-f298-4087-9bf1-27a5649fc307/sub"),
    ("DoKtor 1", "https://raw.githubusercontent.com/parvinxs/Fssociety/refs/heads/main/Fssociety.sub"),
    ("DOKtor", "https://raw.githubusercontent.com/parvinxs/Submahsanetxsparvin/refs/heads/main/Sub.mahsa.xsparvin"),
    ("tepo90_h2", "https://raw.githubusercontent.com/tepo18/tepo90/main/final2.txt"),
    ("hp", "https://raw.githubusercontent.com/tepo80/Trojan/refs/heads/main/hp.txt"),
    ("sab chini 2", "https://almasi-1990.almasi-ali98.workers.dev/522e8484-53de-41a1-a5ba-92e2ec3b7b26/ty"),
    ("shah", "https://raw.githubusercontent.com/tepo98/kv98/refs/heads/main/shah.html"),
    ("sshmax", "https://raw.githubusercontent.com/tepo18/online-sshmax98/main/final.txt"),
    ("vmess", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/vmess.txt"),
    ("ss", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/ss.txt"),
    ("trojan", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/trojan.txt"),
    ("vless", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/vless.txt"),
    ("reality", "https://raw.githubusercontent.com/coldwater-10/V2Hub/main/Split/Base64/reality"),
    ("hamed", "https://zaya.link/Arista_HP_Final#xsfilternet"),
    ("hamed_1", "https://zaya.link/V2GO_everyday"),
    ("sab-vip10", "https://raw.githubusercontent.com/tepo18/sab-vip10/main/final20.txt"),
    ("panel-man", "https://panel-akbar.ahsan-tepo1383online.workers.dev/txt"),
    ("almasi", "https://raw.githubusercontent.com/tepo80/sab-vip90/main/almasi.txt"),
]

public_links = [
    ("tepo80", "https://raw.githubusercontent.com/tepo80/tepo80/main/final.txt"),
    ("tepo18", "https://raw.githubusercontent.com/tepo80/tepo18/main/final.txt"),
    ("tepo18", "https://raw.githubusercontent.com/tepo80/tepo18/main/final.txt"),
    ("sab-vip10", "https://raw.githubusercontent.com/tepo18/sab-vip10/main/final2.txt"),
    ("sab-vip10", "https://raw.githubusercontent.com/tepo18/sab-vip10/main/final.txt"),
    ("tepo80", "https://raw.githubusercontent.com/tepo80/sab-vip90/main/vip.txt"),
    ("panel", "https://panel-akbar.ahsan-tepo1383online.workers.dev/raw"),
    ("tepo90", "https://raw.githubusercontent.com/tepo18/tepo90/main/final2.txt"),
    ("sab-vip90", "https://raw.githubusercontent.com/tepo80/sab-vip90/main/vip.txt"),
    ("tepo90", "https://raw.githubusercontent.com/tepo18/tepo90/main/final2.txt"),
    ("kv98", "https://raw.githubusercontent.com/tepo98/kv98/main/final.txt"),
    ("sab-vip10", "https://raw.githubusercontent.com/tepo18/sab-vip10/main/final20.txt"),
    ("sshmax98", "https://raw.githubusercontent.com/tepo18/online-sshmax98/main/final.txt"),
    ("panel2", "https://3tar100.almasi-ali98.workers.dev/feed?n=1500"),
    ("tepo90", "https://raw.githubusercontent.com/tepo18/tepo90/main/final2.txt"),
    ("tepo80", "https://raw.githubusercontent.com/tepo80/tepo80/refs/heads/main/shah.txt"),
    ("sab-vip90", "https://raw.githubusercontent.com/tepo80/sab-vip90/main/almasi.txt"),
    ("kv98", "https://raw.githubusercontent.com/tepo98/kv98/refs/heads/main/shah.html"),
    ("sab-vip10", "https://raw.githubusercontent.com/tepo18/sab-vip10/main/final60.txt"),
    ("sab-vip10", "https://raw.githubusercontent.com/tepo18/sab-vip10/refs/heads/main/final20.txt"),
]

vip_links = [
    ("online-sshmax98", "https://raw.githubusercontent.com/tepo18/online-sshmax98/main/final2.txt"),
    ("panel-sheek", "https://panel-akbar.ahsan-tepo1383online.workers.dev/txt"),
    ("panel3", "https://panel-akbar.ahsan-tepo1383online.workers.dev/txt"),
    ("panel7", "https://panel-80.almasi-ali98.workers.dev/sub?n=1500&ip=104.16.10.6"),
    ("kv98", "https://raw.githubusercontent.com/tepo98/kv98/main/final.txt"),
    ("arshia", "https://raw.githubusercontent.com/arshiacomplus/v2rayExtractor/main/hy2.html"),
    ("Doktor", "https://raw.githubusercontent.com/parvinxs/Fssociety/refs/heads/main/Fssociety.sub"),
    ("Arista", "https://23.ahsan-tepo20.workers.dev/arista"),
    ("Chain", "https://chine-panel.ahsan-tepo98.workers.dev/c808ce19-f298-4087-9bf1-27a5649fc307/sub"),
    ("Arista2", "https://tepo98.ahsan-tepo20.workers.dev/api/arista-panel-v2ray"),
    ("sab-vip10", "https://raw.githubusercontent.com/tepo18/sab-vip10/refs/heads/main/final10.txt"),
    ("Doktor2", "https://raw.githubusercontent.com/prvinxs/Submahsanetxsparvin/refs/heads/main/Sub.mahsa.xsparvin"),
    ("Hamed", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/hy2.txt"),
    ("Kv98", "https://raw.githubusercontent.com/tepo98/kv98/refs/heads/main/shah.html"),
    ("Trojan ", "https://raw.githubusercontent.com/tepo80/Trojan/refs/heads/main/hp.txt"),
    ("vmess", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/vmess.txt"),
    ("shadows", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/ss.txt"),
    ("reallty", "https://raw.githubusercontent.com/coldwater-10/V2Hub/main/Split/Base64/reality"),
    ("trojan", "https://raw.githubusercontent.com/hamedp-71/v2go_NEW/main/Splitted-By-Protocol/trojan.txt"),
    ("h2", "https://raw.githubusercontent.com/Surfboardv2ray/TGParse/main/python/hy2"),
]

# ==========================
# توابع
# ==========================
def show_submenu(name, links):
    while True:
        print(f"\n{GREEN}{name} Links:{RESET}")
        for idx, (title, _) in enumerate(links, 1):
            print(f"{CYAN}{idx}. {YELLOW}{title}{RESET}")
        print(f"{CYAN}0. {YELLOW}Back{RESET}")

        choice = input(f"{GREEN}Enter your choice: {RESET}").strip()
        if choice == "0":
            break
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(links):
                link = links[idx][1]
                print(f"{GREEN}Opening link: {link}{RESET}")
                os.system(f'am start -a android.intent.action.VIEW -d "{link}" >/dev/null 2>&1')
            else:
                print(f"{RED}Invalid input.{RESET}")
        except ValueError:
            print(f"{RED}Invalid input.{RESET}")


# ==========================
# منوی اصلی
# ==========================
while True:
    print(f"\n{GREEN}Select a subscription type:{RESET}")
    print(f"{CYAN}1. {YELLOW}Private{RESET}")
    print(f"{CYAN}2. {YELLOW}Public{RESET}")
    print(f"{CYAN}3. {YELLOW}VIP{RESET}")
    print(f"{CYAN}0. {YELLOW}Exit{RESET}")

    choice = input(f"{GREEN}Enter your choice: {RESET}").strip()

    if choice == "0":
        print(f"{YELLOW}Exiting...{RESET}")
        break
    elif choice == "1":
        show_submenu("Private", private_links)
    elif choice == "2":
        show_submenu("Public", public_links)
    elif choice == "3":
        show_submenu("VIP", vip_links)
    else:
        print(f"{RED}Invalid input.{RESET}")


