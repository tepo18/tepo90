#!/usr/bin/env python3

import os
import re
import subprocess
import ipaddress
from datetime import datetime
from pathlib import Path
from colorama import Fore, init

init(autoreset=True)

VERSION = "2.0 PRO"

OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

BANNER = f"""
{Fore.CYAN}╔════════════════════════════════════════════════════╗
{Fore.CYAN}║ {Fore.GREEN} EXACT CONFIG COPY & IP REPLACER PRO {Fore.CYAN}       ║
{Fore.CYAN}║ {Fore.YELLOW} Version {VERSION}                              {Fore.CYAN}║
{Fore.CYAN}╚════════════════════════════════════════════════════╝
"""


def clear_screen():
    os.system("clear")


def pause():
    input(f"\n{Fore.GREEN}Press Enter to continue...{Fore.RESET}")


def copy_to_clipboard(text):
    try:
        p = subprocess.Popen(
            ["termux-clipboard-set"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        p.communicate(text.encode("utf-8"))
        return True
    except Exception:
        return False


def clean_text(text):
    return text.strip().replace("\r", "")


def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def extract_ips(text):
    """
    استخراج IP های سالم از متن
    حذف پورت و تکراری ها
    """

    result = []
    items = re.split(r"[\s,;\n\r\t]+", text)

    for item in items:
        item = item.strip()

        if not item:
            continue

        item = re.sub(r":\d+$", "", item)

        if is_valid_ip(item):
            if item not in result:
                result.append(item)

    return result


def detect_protocol(config):

    config_lower = config.lower()

    if config_lower.startswith("vless://"):
        return "VLESS"

    if config_lower.startswith("vmess://"):
        return "VMESS"

    if config_lower.startswith("trojan://"):
        return "TROJAN"

    if config_lower.startswith("ss://"):
        return "SHADOWSOCKS"

    if config_lower.startswith("hysteria"):
        return "HYSTERIA"

    return "UNKNOWN"


def extract_host(config):
    """
    پیدا کردن Host اصلی بدون تغییر بقیه کانفیگ
    """

    config = config.strip()

    if "@" in config:

        try:
            after_at = config.split("@", 1)[1]

            host = re.split(
                r"[:/?#]",
                after_at
            )[0]

            return host

        except:
            pass


    return None
def replace_host(config, old_host, new_ip):
    """
    فقط Host را عوض می‌کند
    بقیه لینک دست نخورده می‌ماند
    """

    if not old_host:
        return config

    new_config = config

    # حالت استاندارد @host:port
    new_config = new_config.replace(
        "@" + old_host + ":",
        "@" + new_ip + ":"
    )

    # حالت @host بدون پورت
    if new_config == config:
        new_config = new_config.replace(
            "@" + old_host,
            "@" + new_ip
        )

    return new_config



def remove_duplicates(items):
    """
    حذف کانفیگ‌های تکراری
    """

    seen = set()
    result = []

    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)

    return result



def load_configs_from_text(text):

    configs = []

    for line in text.splitlines():

        line = line.strip()

        if "://" in line:
            configs.append(line)

    return configs



def load_file(path):

    try:

        with open(
            path,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:

            return f.read()

    except Exception:

        return ""



def save_output(filename, content):

    path = OUTPUT_DIR / filename

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(content)

    return path



def generate_configs(base_configs, ips):

    output = []

    stats = {}

    for config in base_configs:

        proto = detect_protocol(config)

        stats[proto] = stats.get(proto, 0) + 1


        old_host = extract_host(config)


        if not old_host:
            continue


        for ip in ips:

            new_conf = replace_host(
                config,
                old_host,
                ip
            )

            output.append(new_conf)


    output = remove_duplicates(output)

    return output, stats



def show_stats(base, ips, result):

    print("\n" + "="*45)

    print(
        f"{Fore.CYAN}Base Configs : "
        f"{Fore.GREEN}{len(base)}"
    )

    print(
        f"{Fore.CYAN}Clean IPs    : "
        f"{Fore.GREEN}{len(ips)}"
    )

    print(
        f"{Fore.CYAN}Generated    : "
        f"{Fore.GREEN}{len(result)}"
    )

    print("="*45)



def load_scanner_file():

    files = []

    for f in os.listdir("."):

        if (
            f.startswith("SenPaiScannerResult")
            or f.startswith("GOOD")
            or f.startswith("BAD")
        ):
            files.append(f)


    if not files:

        print(
            f"{Fore.RED}No scanner files found."
        )

        return ""


    print("\nAvailable Files:")

    for i, f in enumerate(files):

        print(
            f"[{i}] {f}"
        )


    try:

        choice = int(
            input(
                "\nSelect file: "
            )
        )

        return load_file(
            files[choice]
        )

    except:

        return ""
def main():

    base_configs = []

    while True:

        clear_screen()

        print(BANNER)


        if base_configs:

            print(
                f"{Fore.CYAN}Loaded Configs: "
                f"{Fore.GREEN}{len(base_configs)}"
            )

        else:

            print(
                f"{Fore.CYAN}Loaded Configs: "
                f"{Fore.RED}None"
            )


        print("\n" + "="*45)

        print(
            f"[{Fore.YELLOW}0{Fore.RESET}] Load Configs (Paste)"
        )

        print(
            f"[{Fore.BLUE}1{Fore.RESET}] Load Config File"
        )

        print(
            f"[{Fore.MAGENTA}2{Fore.RESET}] Load SenPai Result File"
        )

        print(
            f"[{Fore.GREEN}3{Fore.RESET}] Generate New Configs"
        )

        print(
            f"[{Fore.RED}9{Fore.RESET}] Exit"
        )

        print("="*45)


        choice = input(
            f"\n{Fore.GREEN}Select: {Fore.RESET}"
        ).strip()



        # EXIT
        if choice == "9":

            clear_screen()
            break



        # PASTE CONFIG
        elif choice == "0":

            clear_screen()

            print(
                f"{Fore.YELLOW}Paste configs"
            )

            print(
                f"{Fore.LIGHTBLACK_EX}"
                "(Finish with CTRL+D)"
                f"{Fore.RESET}\n"
            )


            data = []


            while True:

                try:

                    line = input()

                    if line.strip():

                        data.append(line)

                except EOFError:

                    break


            base_configs = load_configs_from_text(
                "\n".join(data)
            )


            print(
                f"\n{Fore.GREEN}Loaded:"
                f" {len(base_configs)}"
            )

            pause()



        # LOAD FILE
        elif choice == "1":

            filename = input(
                "\nConfig filename: "
            ).strip()


            text = load_file(filename)


            base_configs = load_configs_from_text(
                text
            )


            print(
                f"{Fore.GREEN}Loaded:"
                f" {len(base_configs)}"
            )

            pause()



        # SENPAI FILE
        elif choice == "2":

            text = load_scanner_file()


            ips = extract_ips(text)


            print(
                f"\n{Fore.GREEN}Found IPs:"
                f" {len(ips)}"
            )


            if ips:

                save_output(
                    "scanner_clean_ips.txt",
                    "\n".join(ips)
                )

                print(
                    f"{Fore.CYAN}Saved scanner_clean_ips.txt"
                )


            pause()



        # GENERATE
        elif choice == "3":


            if not base_configs:

                print(
                    f"{Fore.RED}"
                    "Load configs first!"
                )

                pause()
                continue



            print(
                f"\n{Fore.YELLOW}"
                "Paste clean IPs"
            )

            print(
                f"{Fore.LIGHTBLACK_EX}"
                "(CTRL+D when finished)"
                f"{Fore.RESET}\n"
            )


            lines = []


            while True:

                try:

                    line = input()

                    if line.strip():

                        lines.append(line)


                except EOFError:

                    break



            ips = extract_ips(
                "\n".join(lines)
            )


            if not ips:

                print(
                    f"{Fore.RED}"
                    "No valid IP found"
                )

                pause()

                continue



            results, stats = generate_configs(
                base_configs,
                ips
            )


            if not results:

                print(
                    f"{Fore.RED}"
                    "Nothing generated"
                )

                pause()

                continue



            show_stats(
                base_configs,
                ips,
                results
            )



            timestamp = datetime.now().strftime(
                "%Y%m%d_%H%M%S"
            )


            filename = (
                f"exact_configs_{timestamp}.txt"
            )


            output = "\n\n".join(results)



            path = save_output(
                filename,
                output
            )



            print(
                f"\n{Fore.GREEN}✔ Saved:"
                f" {path}"
            )



            if copy_to_clipboard(output):

                print(
                    f"{Fore.GREEN}✔ Copied to clipboard"
                )

            else:

                print(
                    f"{Fore.YELLOW}"
                    "Clipboard unavailable"
                )


            pause()



if __name__ == "__main__":

    main()
