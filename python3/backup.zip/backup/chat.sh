#!/data/data/com.termux/files/usr/bin/bash

API_KEY="sk-nry-FD_wXDaA6A7Z7agc29slY8Zh-2mtEVAayQfUlT8RyxE"
URL="https://router.bynara.id/v1/chat/completions"
MODEL="kimi-k2.7-code-free"

echo "========================================="
echo " Kimi K2.7 Chat"
echo " برای خروج: exit"
echo "========================================="

while true
do
    echo
    read -p "You: " MSG

    [ "$MSG" = "exit" ] && break

    curl -s "$URL" \
      -H "Authorization: Bearer $API_KEY" \
      -H "Content-Type: application/json" \
      -d "{
        \"model\":\"$MODEL\",
        \"messages\":[
          {
            \"role\":\"user\",
            \"content\":\"$MSG\"
          }
        ]
      }" | jq -r '.choices[0].message.content'

done
