#!/usr/bin/env python3
import os

scripts = [

    "bade14.py",
    "bakup.py",
    "bakup2.py",
    "bas.sh",

    "base.py",
    "base1.py",
    "base10.py",
    "base11.py",
    "base12.py",
    "base13.py",
    "base15.py",
    "base16.py",
    "base17.py",
    "base18.py",
    "base19.py",
    "base2.py",
    "base20.py",
    "base21.py",
    "base22.py",
    "base23.py",
    "base24.py",
    "base25.py",
    "base26.py",
    "base27.py",
    "base28.py",
    "base29.py",
    "base3.py",
    "base30.py",
    "base31.py",
    "base32.py",
    "base35.py",
    "base4.py",
    "base5.py",
    "base6.py",
    "base7.py",
    "base8.py",
    "base9.py",

    "bash.sh",
    "bash1.sh",
    "bash10.sh",
    "bash11.sh",
    "bash13.sh",
    "bash14.sh",
    "bash15.sh",
    "bash16.sh",
    "bash17.sh",
    "bash18.sh",
    "bash19.sh",
    "bash2.sh",
    "bash20.sh",
    "bash3.sh",
    "bash4.sh",
    "bash5.sh",
    "bash6.sh",
    "bash7.sh",
    "bash8.sh",
    "bash9.sh",

    "chat.sh",

    "clash.py",
    "clash1.py",
    "clash2.py",

    "clean.txt",
    "clean_ips.sh",
    "clean_ips.txt",

    "cofing.py",

    "cust.sh",
    "cust1.sh",
    "cust2.sh",
    "cust3.sh",
    "cust5.sh",
    "cust6.sh",
    "cust7.sh",
    "cust8.sh",
    "cust9.sh",

    "custom.py",
    "custom.sh",
    "custom1.py",
    "custom1.sh",
    "custom10.py",
    "custom10.sh",
    "custom11.py",
    "custom2.py",
    "custom2.sh",
    "custom3.sh",
    "custom5.py",
    "custom5.sh",

    "cut.py",
    "cut1.py",
    "cut10.py",
    "cut2.py",
    "cut3.py",

    "ether.sh",

    "freg21.py",
    "freg23.py",

    "g.py",
    "go",

    "html-launcher.sh",
    "html.sh",

    "input",
    "input.txt",

    "ip_cleaner.sh",
    "ip_merge.sh",
    "ips.txt",

    "koland.py",
    "koland10.py",
    "link.py",

    "lunch.py",
    "lunch10.py",
    "lunch2.py",
    "lunch3.py",
    "lunch30.py",
    "lunch50.py",
    "lunch90.py",
    "lunch98.py",
    "luncher.py",

    "mago.py",
    "mago1.py",
    "mago3.py",

    "nahan.sh",

    "old.py",
    "old1.py",
    "old10.py",
    "old11.py",
    "old12.py",
    "old13.py",
    "old14.py",
    "old15.py",
    "old16.py",
    "old17.py",
    "old18.py",
    "old19.py",
    "old2.py",
    "old20.py",
    "old21.py",
    "old22.py",
    "old23.py",
    "old24.py",
    "old25.py",
    "old26.py",
    "old27.py",
    "old28.py",
    "old29.py",
    "old3.py",
    "old30.py",
    "old4.py",
    "old5.py",
    "old6.py",
    "old7.py",
    "old8.py",
    "old9.py",

    "omid.py",

    "output_ips.txt",
    "aether.sh",
    "wegard.py",
    "targets.txt",
    "tarkib.sh",
    "omid.py",
    "nahan.sh",

    "lunch.py",
    "lunch10.py",
    "lunch2.py",
    "lunch3.py",
    "lunch30.py",
    "lunch50.py",
    "lunch90.py",
    "lunch98.py",
    "luncher.py",

    "link.py",
    "koland.py",
    "koland10.py",
    "ip_merge.sh",
    "html.sh",
    "ip_cleaner.sh",
    "html-launcher.sh",
    "ether.sh",

    "cut.py",
    "cut1.py",
    "cut10.py",

    "freg21.py",
    "freg23.py",

    "custom.sh",
    "custom.py",
    "custom10.py",
    "custom10.sh",
    "cust5.sh",
    "cust9.sh",

    "cofing.py",

    "clean_ips.sh",
    "clean_ips.txt",

    "bakup2.py",
    "bas.sh",
    "backup.sh",
    "bakup.py",

    "akbar.py",
    "asl.sh",
]


def show_menu():
    os.system("clear")

    print("\033[96m")
    print("╔══════════════════════════════╗")
    print("║       SCANNER LAUNCHER       ║")
    print("╚══════════════════════════════╝")
    print("\033[0m")

    for i, s in enumerate(scripts, 1):
        print(f"\033[92m[{i}]\033[0m {s}")

    print("\n\033[91m[0]\033[0m Exit")


while True:
    show_menu()
    choice = input("Select: ").strip()

    if choice == "0":
        break

    if choice.isdigit():
        idx = int(choice) - 1

        if 0 <= idx < len(scripts):
            file = scripts[idx]

            os.system("clear")
            print(f"Running: {file}\n")

            if file == "Kolande":
                os.system("bash <(curl -fsSL https://raw.githubusercontent.com/Kolandone/Selector/main/Sel.sh)")

            elif file.endswith(".py"):
                os.system(f"python3 '{file}'")

            elif file.endswith(".sh"):
                os.system(f"bash '{file}'")

            else:
                os.system(file)

            input("\nFinished. Press Enter...")
        else:
            input("Invalid!")

        continue

    input("Invalid! Press Enter...")
