#!/data/data/com.termux/files/usr/bin/bash

# Colors
CYAN='\033[1;36m'
GREEN='\033[1;32m'
NC='\033[0m'

clear
echo -e "${CYAN}=== CUSTOM CONFIG GENERATOR ===${NC}"
echo

# ---- INPUTS ----
read -r -p "NAME (remarks): " REMARKS
read -r -p "IP / ADDRESS: " IP

PORT=443

read -r -p "PASSWORD: " PASSWORD
read -r -p "HOST: " HOST
read -r -p "SNI: " SNI
read -r -p "PATH: " PATHWS

echo
echo -e "${GREEN}=== GENERATED CONFIG ===${NC}"
echo

# ---- OUTPUT + COPY TO CLIPBOARD ----
cat <<EOF | tee >(termux-clipboard-set)
{
"remarks": "$REMARKS",

"log": {
"access": "",
"error": "",
"loglevel": "info",
"dnsLog": false
},

"inbounds": [
{
"tag": "in_proxy",
"port": 1080,
"protocol": "socks",
"listen": "0.0.0.0",
"settings": {
"auth": "noauth",
"udp": true,
"userLevel": 8
},
"sniffing": {
"enabled": false
}
},
{
"tag": "http-in",
"port": 10808,
"listen": "::",
"protocol": "http"
}
],

"outbounds": [
{
"tag": "proxy",
"protocol": "trojan",
"settings": {
"servers": [
{
"address": "$IP",
"method": "chacha20-poly1305",
"ota": false,
"password": "$PASSWORD",
"port": $PORT,
"level": 8,
"flow": ""
}
]
},
"streamSettings": {
"network": "ws",
"security": "tls",
"wsSettings": {
"path": "$PATHWS",
"headers": {
