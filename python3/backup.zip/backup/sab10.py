#!/usr/bin/env python3
import os
import json
import base64

# ================== مسیرها ==================
BASE_DIR = "/storage/emulated/0/Download/input.txt"  # مسیر ورودی جهت خواندن فایل‌ها
OUTPUT_DIR = "/storage/emulated/0/Download/v2ray_output"  # مسیر خروجی جهت ذخیره محتوا
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ================== HELPERS ==================
def b64e(s: str) -> str:
    """تبدیل رشته به Base64"""
    return base64.b64encode(s.encode()).decode()

def fix_vmess(link):
    """تبدیل لینک vmess به Base64"""
    try:
        raw = link.replace("vmess://", "")
        j = json.loads(base64.b64decode(raw + "===").decode())
        clean = json.dumps(j, separators=(",", ":"))
        return "vmess://" + b64e(clean)
    except Exception as e:
        return None

def fix_ss(link):
    """تبدیل لینک ss به Base64"""
    try:
        raw = link.replace("ss://", "").split("#")[0]
        base64.b64decode(raw + "===")
        return "ss://" + raw
    except Exception as e:
        try:
            return "ss://" + b64e(raw)
        except Exception as e:
            return None

def normalize(line):
    """تبدیل خطوط پروتکل‌ها به Base64"""
    line = line.strip()
    if not line:
        return None

    if line.startswith("vmess://"):
        return fix_vmess(line)
    if line.startswith("ss://"):
        return fix_ss(line)
    if line.startswith((
        "vless://", "trojan://", "hysteria://", "hysteria2://",
        "tuic://", "socks://", "http://", "https://"
    )):
        return line
    return None

# ================== جستجو و پردازش لینک‌ها ==================
def process_links(links):
    # بررسی اینکه لینک‌ها خالی نباشند
    if not links:
        print(f"[Error] No links provided.")
        return

    # پردازش هر لینک
    for idx, link in enumerate(links, start=1):
        print(f"\nProcessing link {idx}: {link}")
        
        # پردازش لینک
        processed_link = normalize(link)
        
        if processed_link:
            # ================== ذخیره خروجی به فایل ==================
            output_file = os.path.join(OUTPUT_DIR, f"output_{idx}.txt")
            
            # نوشتن خروجی Base64 در فایل جدید
            subscription_raw = processed_link
            subscription_b64 = base64.b64encode(subscription_raw.encode()).decode()

            with open(output_file, "w", encoding="utf-8") as base_file:
                base_file.write(subscription_b64)

            print(f"[✓] Processed and saved to: {output_file}")
        else:
            print(f"[Error] Failed to process link: {link}")

    print("\n[✓] All links processed successfully!")

# ================== دریافت ساب لینک‌ها ==================
def get_links_from_input():
    print("Enter subscription links (one per line). When you're done, press Ctrl+D or Enter an empty line to finish:")
    
    links = []
    while True:
        try:
            line = input()
            if not line.strip():
                break
            links.append(line.strip())
        except EOFError:
            break

    return links

# ================== ریست کردن فایل ورودی (پاک کردن محتویات نانو) ==================
def reset_input_file():
    with open(BASE_DIR, "w", encoding="utf-8") as file:
        file.write("")  # نوشتن رشته خالی برای پاک کردن محتویات

# ================== اجرای پردازش ==================
if __name__ == "__main__":
    links = get_links_from_input()
    process_links(links)
    reset_input_file()  # ریست کردن فایل ورودی پس از پردازش
