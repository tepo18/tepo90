cat << 'EOF' > cofing.py
import os
import re
import json
import base64
import subprocess
import requests
import random
from datetime import datetime
import ipaddress
from colorama import Fore, Back, Style, init

# Initialize colorama
init(autoreset=True)

BANNER = f"""
{Fore.CYAN}╔════════════════════════════════════════════════════╗
{Fore.CYAN}║ {Fore.GREEN} 🚀 TERMUX CONFIG GENERATOR PRO (CLI EDITION) {Fore.CYAN} ║
{Fore.CYAN}║ {Fore.YELLOW}  Advanced V2Ray/WireGuard IP Replacer Tool   {Fore.CYAN} ║
{Fore.CYAN}╚════════════════════════════════════════════════════╝
"""

def clear_screen():
    os.system('clear')

def show_message(text, msg_type="info"):
    if msg_type == "success":
        print(f"[{Fore.GREEN}✔{Fore.RESET}] {Fore.GREEN}{text}")
    elif msg_type == "warning":
        print(f"[{Fore.YELLOW}!{Fore.RESET}] {Fore.YELLOW}{text}")
    elif msg_type == "error":
        print(f"[{Fore.RED}✘{Fore.RESET}] {Fore.RED}{text}")
    else:
        print(f"[{Fore.BLUE}ℹ{Fore.RESET}] {text}")

def copy_to_clipboard(text):
    try:
        process = subprocess.Popen(['termux-clipboard-set'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        process.communicate(input=text.encode('utf-8'))
        return True
    except FileNotFoundError:
        return False

def detect_config_type(config):
    for p_type in ['vmess', 'vless', 'wireguard', 'trojan']:
        if config.startswith(f"{p_type}://"):
            return p_type
    return None

def replace_ip_in_config(config, ip_str, port=None):
    c_type = detect_config_type(config)
    if not c_type:
        return None
    try:
        if c_type == 'vmess':
            b64_part = config.replace('vmess://', '').strip()
            b64_part += "=" * ((4 - len(b64_part) % 4) % 4)
            decoded = base64.b64decode(b64_part).decode('utf-8')
            data = json.loads(decoded)
            data['add'] = ip_str
            if port:
                data['port'] = int(port)
            new_b64 = base64.b64encode(json.dumps(data, ensure_ascii=False).encode('utf-8')).decode('utf-8')
            return f"vmess://{new_b64}\n\n"
        
        elif c_type == 'vless':
            if ":" in ip_str and not ip_str.startswith("["):
                ip_str = f"[{ip_str}]"
            match = re.match(r"^(vless://[^@]+)@([^:]+):(\d+)(.*)$", config)
            if match:
                start, _, old_port, end = match.groups()
                return f"{start}@{ip_str}:{port or old_port}{end}\n\n"
        
        elif c_type in ['wireguard', 'trojan']:
            regex = r"^(" + c_type + r"://[^@]+@)[^:]+:(\d+)(.*)$"
            match = re.match(regex, config)
            if match:
                start, old_port, end = match.groups()
                return f"{start}{ip_str}:{port or old_port}{end}\n\n"
    except Exception as e:
        return None
    return None

def extract_ips_from_text(raw_text):
    ipv4s = re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", raw_text)
    ipv6s = re.findall(r"(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:)*:[a-fA-F0-9]{1,4}(?::[a-fA-F0-9]{1,4})*", raw_text)
    valid_ips = []
    for ip in list(set(ipv4s + ipv6s)):
        try:
            ipaddress.ip_address(ip)
            valid_ips.append(ip)
        except ValueError:
            pass
    return valid_ips

def get_base_configs():
    clear_screen()
    print(BANNER)
    print(f"{Fore.YELLOW}>> Paste your Base Config(s) below.")
    print(f"{Fore.LIGHTBLACK_EX}(Press ENTER, then CTRL+D when finished){Fore.RESET}")
    
    base_input = []
    while True:
        try:
            line = input()
            if line.strip():
                base_input.append(line.strip())
        except EOFError:
            break
            
    base_configs = [c for c in base_input if detect_config_type(c)]
    return base_configs

def generate_and_save(base_configs, ip_list, port=None):
    if not ip_list:
        show_message("No IPs to process.", "warning")
        input("\nPress Enter to return to menu...")
        return

    generated = []
    for config in base_configs:
        for ip in ip_list:
            new_conf = replace_ip_in_config(config, ip, port)
            if new_conf:
                generated.append(new_conf)

    if not generated:
        show_message("Failed to generate configs.", "error")
        input("\nPress Enter to return to menu...")
        return

    final_output = "".join(generated)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"configs_{timestamp}.txt"
    
    with open(filename, "w", encoding="utf-8") as f:
        f.write(final_output)

    print("-" * 40)
    show_message(f"Successfully generated {len(generated)} configs!", "success")
    show_message(f"Saved to: {Fore.CYAN}{filename}", "info")
    
    if copy_to_clipboard(final_output.strip()):
        show_message("Outputs copied to Clipboard successfully!", "success")
    else:
        show_message("Could not access clipboard. Make sure Termux:API is installed.", "warning")
    
    input(f"\n{Fore.GREEN}Press Enter to return to Main Menu...{Fore.RESET}")

def fetch_cdn_ranges(service):
    url = f"https://raw.githubusercontent.com/seramo/cdn-ip-ranges/main/{service}.json"
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            ips = data.get("ipv4", [])
            return ips
    except Exception as e:
        show_message(f"Failed to fetch {service} ranges.", "error")
    return []

def main():
    base_configs = []
    
    while True:
        clear_screen()
        print(BANNER)
        
        if base_configs:
            print(f"{Fore.CYAN}Loaded Base Configs: {Fore.GREEN}{len(base_configs)}")
        else:
            print(f"{Fore.CYAN}Loaded Base Configs: {Fore.RED}None")
            
        print("\n" + "="*30)
        print(f"[{Fore.YELLOW}0{Fore.RESET}] {Fore.YELLOW}Load / Change Base Configs")
        print(f"[{Fore.CYAN}1{Fore.RESET}] Paste Clean IPs via Nano Editor")
        print(f"[{Fore.CYAN}2{Fore.RESET}] Convert CIDR Range to IP Configs")
        print(f"[{Fore.CYAN}3{Fore.RESET}] Download Cloudflare / CDN IPs automatically")
        print(f"[{Fore.CYAN}4{Fore.RESET}] SNI & Port Spoofing (Single IP/Domain)")
        print(f"[{Fore.RED}9{Fore.RESET}] {Fore.RED}Exit")
        print("="*30)
        
        choice = input(f"\n{Fore.GREEN}Select an option:{Fore.RESET} ").strip()
        
        if choice == '9':
            clear_screen()
            print(f"{Fore.CYAN}Goodbye!{Fore.RESET}")
            break
            
        if choice == '0':
            base_configs = get_base_configs()
            if not base_configs:
                show_message("No valid base configs loaded.", "warning")
                import time
                time.sleep(2)
            continue
            
        if not base_configs:
            show_message("Please Load Base Configs first (Option 0)!", "error")
            input("\nPress Enter to continue...")
            continue
            
        if choice == '1':
            temp_file = "temp_nano_ips.txt"
            print(f"\n{Fore.YELLOW}Opening Nano Editor...")
            print(f"{Fore.LIGHTBLACK_EX}(Paste IPs -> Ctrl+O to Save -> Enter -> Ctrl+X to Exit){Fore.RESET}")
            input("Press Enter to launch Nano...")
            os.system(f"nano {temp_file}")
            
            if os.path.exists(temp_file):
                with open(temp_file, "r") as f:
                    ips = extract_ips_from_text(f.read())
                os.remove(temp_file)
                generate_and_save(base_configs, ips)
                
        elif choice == '2':
            cidr_input = input(f"\n{Fore.CYAN}Enter CIDR block (e.g., 104.18.0.0/24): {Fore.RESET}").strip()
            limit_str = input(f"{Fore.CYAN}Max output configs [Default 50]: {Fore.RESET}").strip()
            limit = int(limit_str) if limit_str.isdigit() else 50
            
            try:
                network = ipaddress.ip_network(cidr_input, strict=False)
                ips = []
                for ip in network.hosts():
                    ips.append(str(ip))
                    if len(ips) >= limit:
                        break
                generate_and_save(base_configs, ips)
            except ValueError:
                show_message("Invalid CIDR format.", "error")
                input("\nPress Enter to return...")
                
        elif choice == '3':
            print(f"\n{Fore.CYAN}Select CDN Service:{Fore.RESET}")
            print("1. Cloudflare\n2. GCore\n3. Cloudfront")
            sub_choice = input(f"{Fore.GREEN}Choice: {Fore.RESET}").strip()
            
            service_map = {'1': 'cloudflare', '2': 'gcore', '3': 'cloudfront'}
            srv = service_map.get(sub_choice)
            
            if srv:
                show_message(f"Downloading IP ranges for {srv}...", "info")
                fetched_cidrs = fetch_cdn_ranges(srv)
                if fetched_cidrs:
                    random.shuffle(fetched_cidrs)
                    selected_cidrs = fetched_cidrs[:2]
                    
                    final_ips = []
                    for cidr in selected_cidrs:
                        try:
                            net = ipaddress.ip_network(cidr, strict=False)
                            for i, ip in enumerate(net.hosts()):
                                final_ips.append(str(ip))
                                if i > 10:
                                    break
                        except: pass
                        
                    show_message(f"Extracted {len(final_ips)} random IPs from {srv}.", "success")
                    generate_and_save(base_configs, final_ips)
                else:
                    show_message("Failed to fetch IPs or list is empty.", "error")
            else:
                show_message("Invalid choice.", "error")
            
        elif choice == '4':
            spoof_ip = input(f"\n{Fore.CYAN}Enter New IP / Domain: {Fore.RESET}").strip()
            spoof_port = input(f"{Fore.CYAN}Enter Port (Press Enter to skip): {Fore.RESET}").strip()
            if spoof_ip:
                generate_and_save(base_configs, [spoof_ip], spoof_port if spoof_port else None)
            else:
                show_message("IP/Domain cannot be empty.", "error")
                input("\nPress Enter to return...")

if __name__ == "__main__":
    main()
EOF
