import os
from pathlib import Path
from collections import Counter

# ---------- Colors ----------
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'

# ---------- Default Path ----------
DEFAULT_OUTPUT_DIR = "/sdcard/Download/mix98"

# ---------- Input Phase ----------
print(f"{Colors.HEADER}Paste your links (one per line). Press Enter on empty line or Ctrl+D when done:{Colors.ENDC}")

lines = []
try:
    while True:
        line = input()
        if line.strip() == "":
            break
        lines.append(line.strip())
except EOFError:
    pass

if not lines:
    print(f"{Colors.FAIL}❌ No input provided. Exiting.{Colors.ENDC}")
    exit()

# ---------- Protocol Separation ----------
vless_links = [l for l in lines if l.startswith("vless://")]
trojan_links = [l for l in lines if l.startswith("trojan://")]
ss_links = [l for l in lines if l.startswith("ss://") or l.startswith("ssss://")]

# Keep all links (no duplicate removal)
all_links = vless_links + trojan_links + ss_links

if not all_links:
    print(f"{Colors.FAIL}❌ No valid links detected.{Colors.ENDC}")
    exit()

# ---------- Statistics ----------
def print_stats(vless, trojan, ss):
    total = len(vless) + len(trojan) + len(ss)
    print(f"{Colors.OKBLUE}\n=============== STATISTICS ==============={Colors.ENDC}")
    print(f"{Colors.OKGREEN}{'Protocol':<10} {'Count':>5}{Colors.ENDC}")
    print(f"{'VLESS':<10} {len(vless):>5}")
    print(f"{'Trojan':<10} {len(trojan):>5}")
    print(f"{'SS/SSS':<10} {len(ss):>5}")
    print(f"{'-'*20}")
    print(f"{'Total':<10} {total:>5}")
    print(f"{Colors.OKBLUE}==========================================={Colors.ENDC}\n")

print_stats(vless_links, trojan_links, ss_links)

# ---------- File Name ----------
file_name = input(f"{Colors.HEADER}Enter file/folder name: {Colors.ENDC}").strip()
if not file_name:
    print(f"{Colors.FAIL}❌ No name entered. Exiting.{Colors.ENDC}")
    exit()

# ---------- Number per File ----------
while True:
    try:
        num_per_file = int(input(f"{Colors.HEADER}Enter number of configs per file: {Colors.ENDC}").strip())
        if num_per_file <= 0:
            raise ValueError
        break
    except ValueError:
        print(f"{Colors.WARNING}⚠️ Please enter a valid positive number.{Colors.ENDC}")

# ---------- Save ----------
output_path = Path(DEFAULT_OUTPUT_DIR) / file_name
output_path.mkdir(parents=True, exist_ok=True)

total = len(all_links)
num_files = (total + num_per_file - 1) // num_per_file

for i in range(num_files):
    start = i * num_per_file
    end = min(start + num_per_file, total)
    batch = all_links[start:end]
    file_path = output_path / f"input{i+1}.txt"
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(batch))
    print(f"{Colors.OKGREEN}✔ Saved {len(batch)} configs to {file_path.name}{Colors.ENDC}")

print(f"{Colors.OKBLUE}\n✅ All files saved in: {output_path}{Colors.ENDC}")

