#!/usr/bin/env python3

import os
import shutil
import sys

# ============================================================
# CONFIG
# ============================================================

HOME = os.path.expanduser("~")
BACKUP_DIR = os.path.join(
    HOME,
    "storage",
    "downloads",
    "backup"
)

# ============================================================
# COLORS
# ============================================================

RESET = "\033[0m"
BOLD = "\033[1m"

RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
CYAN = "\033[96m"
WHITE = "\033[97m"
MAGENTA = "\033[95m"


# ============================================================
# SCREEN
# ============================================================

def clear_screen():
    os.system("clear")


def pause():
    input(f"\n{YELLOW}Press ENTER to continue...{RESET}")


# ============================================================
# HEADER
# ============================================================

def header():
    print(f"{CYAN}{BOLD}")
    print("================================================")
    print("        PYTHON / SHELL BACKUP & RESTORE")
    print("================================================")
    print(f"{RESET}")


# ============================================================
# FIND PYTHON / SHELL FILES IN HOME
# ============================================================

def get_home_scripts():

    scripts = []

    try:

        for name in os.listdir(HOME):

            path = os.path.join(HOME, name)

            # Only files directly inside Home
            if not os.path.isfile(path):
                continue

            # Only Python and Shell
            if name.endswith(".py") or name.endswith(".sh"):
                scripts.append(path)

    except Exception as error:

        print(
            f"{RED}Error reading Home: "
            f"{error}{RESET}"
        )

    return scripts


# ============================================================
# GIVE EXECUTE PERMISSION TO ALL PYTHON / SHELL FILES
# ============================================================

def set_execute_permissions():

    count = 0

    try:

        for name in os.listdir(HOME):

            path = os.path.join(HOME, name)

            if not os.path.isfile(path):
                continue

            if not (
                name.endswith(".py")
                or name.endswith(".sh")
            ):
                continue

            try:

                current_mode = os.stat(path).st_mode

                os.chmod(
                    path,
                    current_mode | 0o111
                )

                count += 1

            except Exception:
                pass

    except Exception:
        pass

    return count


# ============================================================
# BACKUP
# ============================================================

def backup():

    clear_screen()
    header()

    print(f"{BLUE}{BOLD}Creating backup...{RESET}")
    print()

    try:

        # Remove previous backup
        if os.path.exists(BACKUP_DIR):

            print(
                f"{YELLOW}"
                "Removing old backup..."
                f"{RESET}"
            )

            shutil.rmtree(BACKUP_DIR)

        # Create fresh backup directory
        os.makedirs(
            BACKUP_DIR,
            exist_ok=True
        )

        # Find scripts
        scripts = get_home_scripts()

        if not scripts:

            print(
                f"{YELLOW}"
                "No .py or .sh files found in Home."
                f"{RESET}"
            )

            pause()
            return

        copied = 0

        for source in scripts:

            filename = os.path.basename(source)

            destination = os.path.join(
                BACKUP_DIR,
                filename
            )

            try:

                shutil.copy2(
                    source,
                    destination
                )

                copied += 1

            except Exception as error:

                print(
                    f"{RED}"
                    f"Failed: {filename}"
                    f"{RESET}"
                )

                print(
                    f"{RED}{error}{RESET}"
                )

        print()
        print(
            f"{GREEN}{BOLD}"
            "================================"
            f"{RESET}"
        )

        print(
            f"{GREEN}{BOLD}"
            "BACKUP COMPLETE"
            f"{RESET}"
        )

        print(
            f"{GREEN}"
            f"Files copied: {copied}"
            f"{RESET}"
        )

        print()
        print(
            f"{CYAN}"
            "Backup location:"
            f"{RESET}"
        )

        print(
            f"{WHITE}"
            f"{BACKUP_DIR}"
            f"{RESET}"
        )

    except Exception as error:

        print()
        print(
            f"{RED}{BOLD}"
            "BACKUP ERROR"
            f"{RESET}"
        )

        print(
            f"{RED}{error}{RESET}"
        )

    pause()


# ============================================================
# RESTORE
# ============================================================

def restore():

    clear_screen()
    header()

    print(
        f"{BLUE}{BOLD}"
        "Restoring from backup..."
        f"{RESET}"
    )

    print()

    # Check backup directory
    if not os.path.isdir(BACKUP_DIR):

        print(
            f"{RED}{BOLD}"
            "Backup folder not found!"
            f"{RESET}"
        )

        print()

        print(
            f"{YELLOW}"
            f"{BACKUP_DIR}"
            f"{RESET}"
        )

        pause()
        return

    try:

        restored = 0
        skipped = 0

        # Read backup directory
        for filename in os.listdir(BACKUP_DIR):

            source = os.path.join(
                BACKUP_DIR,
                filename
            )

            # Only files
            if not os.path.isfile(source):
                continue

            # Only Python and Shell
            if not (
                filename.endswith(".py")
                or filename.endswith(".sh")
            ):
                continue

            destination = os.path.join(
                HOME,
                filename
            )

            try:

                # Remove existing same-name file
                if os.path.exists(destination):

                    os.remove(destination)

                # Restore backup file
                shutil.copy2(
                    source,
                    destination
                )

                restored += 1

                print(
                    f"{GREEN}"
                    f"[RESTORED] "
                    f"{filename}"
                    f"{RESET}"
                )

            except Exception as error:

                skipped += 1

                print(
                    f"{RED}"
                    f"[FAILED] "
                    f"{filename}"
                    f"{RESET}"
                )

                print(
                    f"{RED}{error}{RESET}"
                )

        # ====================================================
        # AFTER RESTORE
        # GIVE EXECUTE PERMISSION TO ALL .PY / .SH IN HOME
        # ====================================================

        print()

        print(
            f"{YELLOW}"
            "Setting execute permissions..."
            f"{RESET}"
        )

        permission_count = (
            set_execute_permissions()
        )

        print()

        print(
            f"{GREEN}{BOLD}"
            "================================"
            f"{RESET}"
        )

        print(
            f"{GREEN}{BOLD}"
            "RESTORE COMPLETE"
            f"{RESET}"
        )

        print(
            f"{GREEN}"
            f"Files restored: {restored}"
            f"{RESET}"
        )

        if skipped > 0:

            print(
                f"{YELLOW}"
                f"Failed files: {skipped}"
                f"{RESET}"
            )

        print(
            f"{GREEN}"
            f"Executable scripts: "
            f"{permission_count}"
            f"{RESET}"
        )

        print()
        print(
            f"{CYAN}"
            "Restored to:"
            f"{RESET}"
        )

        print(
            f"{WHITE}"
            f"{HOME}"
            f"{RESET}"
        )

    except Exception as error:

        print()
        print(
            f"{RED}{BOLD}"
            "RESTORE ERROR"
            f"{RESET}"
        )

        print(
            f"{RED}{error}{RESET}"
        )

    pause()


# ============================================================
# MENU
# ============================================================

def menu():

    while True:

        clear_screen()
        header()

        print(
            f"{GREEN}{BOLD}"
            "[1]"
            f"{RESET} "
            f"{WHITE}"
            "Backup"
            f"{RESET}"
        )

        print(
            f"{YELLOW}{BOLD}"
            "[2]"
            f"{RESET} "
            f"{WHITE}"
            "Restore"
            f"{RESET}"
        )

        print(
            f"{RED}{BOLD}"
            "[3]"
            f"{RESET} "
            f"{WHITE}"
            "Exit"
            f"{RESET}"
        )

        print()

        choice = input(
            f"{CYAN}{BOLD}"
            "Select: "
            f"{RESET}"
        ).strip()

        # BACKUP
        if choice == "1":

            backup()

        # RESTORE
        elif choice == "2":

            restore()

        # EXIT
        elif choice == "3":

            clear_screen()

            print(
                f"{GREEN}{BOLD}"
                "Goodbye!"
                f"{RESET}"
            )

            sys.exit(0)

        # INVALID
        else:

            print()

            print(
                f"{RED}"
                "Invalid option!"
                f"{RESET}"
            )

            pause()


# ============================================================
# START PROGRAM
# ============================================================

if __name__ == "__main__":

    try:

        menu()

    except KeyboardInterrupt:

        print()

        print(
            f"{YELLOW}"
            "Program stopped."
            f"{RESET}"
        )

        sys.exit(0)
