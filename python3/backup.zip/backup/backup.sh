#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
from datetime import datetime
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

console = Console()

BASE_BACKUP_DIR = "/sdcard/Download/akbar98"
TERMUX_HOME = "/data/data/com.termux/files/home"

os.makedirs(BASE_BACKUP_DIR, exist_ok=True)

def backup_selected():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(BASE_BACKUP_DIR, f"backup_{timestamp}")
    os.makedirs(backup_dir, exist_ok=True)

    count = 0

    for root, dirs, files in os.walk(TERMUX_HOME):
        rel_path = os.path.relpath(root, TERMUX_HOME)
        dest_dir = os.path.join(backup_dir, rel_path) if rel_path != "." else backup_dir
        os.makedirs(dest_dir, exist_ok=True)

        for f in files:
            if f.endswith((".py", ".sh")):
                shutil.copy2(os.path.join(root, f), dest_dir)
                count += 1

    console.print(f"[green]Backup done[/green] | Files: {count}")


def backup_by_name():
    name = Prompt.ask("Enter base name (example: almas)").strip()

    if not name:
        console.print("[red]Name empty[/red]")
        return

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(BASE_BACKUP_DIR, f"{name}_backup_{timestamp}")
    os.makedirs(backup_dir, exist_ok=True)

    count = 0

    for root, dirs, files in os.walk(TERMUX_HOME):
        rel_path = os.path.relpath(root, TERMUX_HOME)
        dest_dir = os.path.join(backup_dir, rel_path) if rel_path != "." else backup_dir

        for f in files:
            if f.startswith(name) and f.endswith(".py"):
                os.makedirs(dest_dir, exist_ok=True)
                shutil.copy2(os.path.join(root, f), dest_dir)
                count += 1

    if count == 0:
        shutil.rmtree(backup_dir, ignore_errors=True)
        console.print("[red]No files found[/red]")
        return

    console.print(f"[green]Backup done[/green] | Files: {count}")


def restore_files():
    backups = sorted(os.listdir(BASE_BACKUP_DIR), reverse=True)

    if not backups:
        console.print("[red]No backups[/red]")
        return

    table = Table(title="Backups")
    table.add_column("No")
    table.add_column("Name")

    for i, b in enumerate(backups):
        table.add_row(str(i + 1), b)

    console.print(table)

    choice = Prompt.ask("Select backup (0 cancel)", default="0")

    if choice == "0":
        return

    try:
        folder = backups[int(choice) - 1]
    except:
        console.print("[red]Invalid[/red]")
        return

    src = os.path.join(BASE_BACKUP_DIR, folder)

    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        dst = os.path.join(TERMUX_HOME, rel) if rel != "." else TERMUX_HOME
        os.makedirs(dst, exist_ok=True)

        for f in files:
            if f.endswith((".py", ".sh")):
                shutil.copy2(os.path.join(root, f), dst)

    console.print("[green]Restore done[/green]")


def main():
    while True:
        console.print("\n1 Backup ALL")
        console.print("2 Restore")
        console.print("3 Backup by name")
        console.print("0 Exit")

        c = Prompt.ask("Select", default="0")

        if c == "1":
            backup_selected()
        elif c == "2":
            restore_files()
        elif c == "3":
            backup_by_name()
        elif c == "0":
            break
        else:
            console.print("Invalid")


if __name__ == "__main__":
    main()
