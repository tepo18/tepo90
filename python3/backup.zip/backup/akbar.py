#!/usr/bin/env python3

import os
import re
import random
import subprocess

INPUT = "input.txt"
OUTPUT = "output_ips.txt"

# اگر فایل وجود ندارد بساز
if not os.path.exists(INPUT):
    open(INPUT, "w").close()

# باز کردن Nano
os.system(f"nano {INPUT}")

# خواندن محتوا
with open(INPUT, "r", encoding="utf-8", errors="ignore") as f:
    data = f.read()

# استخراج IPv4
ips = re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', data)

valid = []

for ip in ips:
    try:
        if all(0 <= int(x) <= 255 for x in ip.split(".")):
            valid.append(ip)
    except:
        pass

# حذف تکراری
valid = list(dict.fromkeys(valid))

# رندوم کردن
random.shuffle(valid)

# ذخیره خروجی
with open(OUTPUT, "w") as f:
    f.write("\n".join(valid))

# کپی خودکار به کلیپ‌بورد اندروید (در صورت نصب termux-api)
try:
    subprocess.run(
        ["termux-clipboard-set"],
        input="\n".join(valid),
        text=True,
        check=True
    )
    print("\n\033[92m✓ Output copied to Android clipboard.\033[0m")
except:
    print("\n\033[93m! termux-api not installed. Clipboard skipped.\033[0m")

# نمایش خروجی
print("\n\033[96m========== OUTPUT ==========\033[0m\n")
for ip in valid:
    print(ip)

print(f"\n\033[92mTotal IPs: {len(valid)}\033[0m")
print(f"\033[92mSaved to: {OUTPUT}\033[0m")

# خالی کردن فایل ورودی برای اجرای بعدی
open(INPUT, "w").close()

print("\033[91mInput file cleared for next run.\033[0m")
